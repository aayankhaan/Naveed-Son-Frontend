// ========================================
// Shipment.jsx
// Pending invoiced orders waiting to ship. Enter qty shipped per line;
// waste = made − shipped. Confirm marks the order shipped.
// ========================================

import { useCallback, useEffect, useMemo, useState } from "react";
import { FONT, COLORS } from "../constants/theme";
import Sidebar from "../components/layout/Sidebar";
import MiniStat from "../components/ui/MiniStat";
import { SearchIcon, ChevronIcon } from "../components/icons/CommonIcons";
import { apiFetch } from "../lib/api";

async function readApiError(res, fallback) {
  try {
    const data = await res.json();
    return data.error || fallback;
  } catch {
    return fallback;
  }
}

function formatDate(dateStr) {
  if (!dateStr) return "";
  const d = new Date(dateStr);
  if (Number.isNaN(d.getTime())) return String(dateStr);
  return d.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "2-digit" });
}

function formatDateTime(value) {
  if (!value) return "";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleString(undefined, {
    day: "2-digit",
    month: "short",
    year: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function draftToShipState(items) {
  const out = {};
  for (const it of items || []) {
    const made = Math.max(0, Math.round(Number(it.qty_made) || 0));
    out[it.item_key] = String(made);
  }
  return out;
}

function lineTotals(drafts, qtyMap) {
  let ordered = 0;
  let made = 0;
  let shipped = 0;
  let waste = 0;
  let invalid = false;
  for (const it of drafts || []) {
    const m = Math.max(0, Math.round(Number(it.qty_made) || 0));
    const o = Math.max(0, Math.round(Number(it.qty_ordered) || 0));
    const raw = qtyMap?.[it.item_key];
    const s = Math.round(Number(raw === "" || raw == null ? m : raw) || 0);
    if (s < 0 || s > m) invalid = true;
    const capped = Math.min(Math.max(0, s), m);
    ordered += o;
    made += m;
    shipped += capped;
    waste += Math.max(0, m - capped);
  }
  return { ordered, made, shipped, waste, invalid };
}

function WaitingIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M2 11.5V5.8L8 3l6 2.8v5.7L8 14.2 2 11.5z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M2 5.8L8 8.6l6-2.8M8 8.6V14.2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function TruckIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M1.5 3.5h8v7h-8v-7z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M9.5 6h3.2L14.5 8.2V10.5h-5" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
      <circle cx="4.2" cy="12" r="1.3" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="12" cy="12" r="1.3" stroke="currentColor" strokeWidth="1.2" />
    </svg>
  );
}

function WasteIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M3 5h10M6 5V3.5h4V5M5 5l.6 8h4.8L11 5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function DoneIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="5.5" stroke="currentColor" strokeWidth="1.3" />
      <path d="M5.2 8.1l1.8 1.8 3.8-3.8" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function EmptyBoxIcon() {
  return (
    <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
      <path d="M6 26V14.5L20 8l14 6.5V26L20 32.5 6 26z" stroke={COLORS.goldDim} strokeWidth="1.6" strokeLinejoin="round" />
      <path d="M6 14.5L20 21l14-6.5M20 21v11.5" stroke={COLORS.goldDim} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function MetricChip({ label, value, tone = "default" }) {
  const tones = {
    default: { bg: COLORS.bone, fg: COLORS.ink, label: COLORS.graphiteLight },
    ship: { bg: COLORS.goldSoft, fg: COLORS.ink, label: COLORS.goldDim },
    waste: { bg: COLORS.rustSoft, fg: COLORS.rust, label: COLORS.rust },
    ok: { bg: COLORS.greenSoft, fg: COLORS.green, label: COLORS.green },
  };
  const t = tones[tone] || tones.default;
  return (
    <div className="rounded-xl px-3 py-2 min-w-[72px]" style={{ background: t.bg }}>
      <div className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: t.label }}>
        {label}
      </div>
      <div className="text-[16px] font-semibold tabular-nums mt-0.5 leading-none" style={{ color: t.fg }}>
        {Number(value || 0).toLocaleString()}
      </div>
    </div>
  );
}

function ShipProgress({ made, shipped }) {
  const pct = made > 0 ? Math.min(100, Math.round((shipped / made) * 100)) : 0;
  return (
    <div className="w-full max-w-[160px]">
      <div className="flex items-center justify-between text-[10.5px] mb-1">
        <span style={{ color: COLORS.graphiteLight }}>Ship progress</span>
        <span className="font-semibold tabular-nums" style={{ color: COLORS.ink }}>
          {pct}%
        </span>
      </div>
      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: COLORS.boneDim }}>
        <div
          className="h-full rounded-full ship-bar"
          style={{
            width: `${pct}%`,
            background: pct >= 100 ? COLORS.green : COLORS.gold,
          }}
        />
      </div>
    </div>
  );
}

function PendingCard({
  order,
  open,
  onToggle,
  qtyMap,
  notes,
  onNotes,
  onQty,
  onShipAll,
  onConfirm,
  saving,
  index,
}) {
  const drafts = order.draft_items || [];
  const totals = lineTotals(drafts, qtyMap);

  return (
    <div
      className="ship-card fade-in rounded-2xl overflow-hidden"
      style={{
        background: COLORS.card,
        border: `1px solid ${open ? COLORS.gold : COLORS.border}`,
        boxShadow: open ? "0 16px 36px -28px rgba(28,25,23,0.45)" : "none",
        animationDelay: `${index * 50}ms`,
      }}
    >
      <button type="button" className="w-full text-left px-5 py-4" onClick={onToggle}>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span
                className="text-[11px] font-bold px-2 py-0.5 rounded"
                style={{ background: COLORS.ink, color: COLORS.gold }}
              >
                ATM {order.atm_no}
              </span>
              {order.bill_no ? (
                <span
                  className="text-[10.5px] font-semibold px-2 py-0.5 rounded"
                  style={{ background: COLORS.goldSoft, color: COLORS.goldDim }}
                >
                  Bill {order.bill_no}
                </span>
              ) : null}
              <span
                className="text-[10.5px] font-medium px-2 py-0.5 rounded"
                style={{ background: COLORS.boneDim, color: COLORS.graphite }}
              >
                Waiting
              </span>
            </div>
            <div className="text-[15px] font-semibold mt-2 truncate" style={{ color: COLORS.ink }}>
              {order.customer}
            </div>
            <div className="text-[11.5px] mt-0.5" style={{ color: COLORS.graphiteLight }}>
              Order {formatDate(order.order_date)}
              {drafts.length ? ` · ${drafts.length} line${drafts.length === 1 ? "" : "s"}` : ""}
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="hidden sm:flex items-center gap-2">
              <MetricChip label="Made" value={totals.made} />
              <MetricChip label="Ship" value={totals.shipped} tone="ship" />
              <MetricChip
                label="Waste"
                value={totals.waste}
                tone={totals.waste > 0 ? "waste" : "ok"}
              />
            </div>
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-transform"
              style={{
                background: COLORS.boneDim,
                color: COLORS.graphite,
                transform: open ? "rotate(-90deg)" : "rotate(90deg)",
              }}
            >
              <ChevronIcon />
            </div>
          </div>
        </div>

        <div className="sm:hidden flex gap-2 mt-3">
          <MetricChip label="Made" value={totals.made} />
          <MetricChip label="Ship" value={totals.shipped} tone="ship" />
          <MetricChip label="Waste" value={totals.waste} tone={totals.waste > 0 ? "waste" : "ok"} />
        </div>

        <div className="mt-3.5">
          <ShipProgress made={totals.made} shipped={totals.shipped} />
        </div>
      </button>

      {open && (
        <div className="px-5 pb-5" style={{ borderTop: `1px solid ${COLORS.border}` }}>
          <div className="flex flex-wrap items-center justify-between gap-2 pt-4 mb-3">
            <p className="text-[12px]" style={{ color: COLORS.graphite }}>
              Enter how many leave the factory. Waste fills in automatically.
            </p>
            <button
              type="button"
              className="btn-secondary text-[11.5px] font-semibold px-3 py-1.5 rounded-lg"
              style={{ background: COLORS.bone, border: `1px solid ${COLORS.border}`, color: COLORS.ink }}
              onClick={onShipAll}
            >
              Fill max (all made)
            </button>
          </div>

          <div className="space-y-2.5">
            {drafts.map((it) => {
              const made = Math.max(0, Math.round(Number(it.qty_made) || 0));
              const ordered = Math.max(0, Math.round(Number(it.qty_ordered) || 0));
              const raw = qtyMap?.[it.item_key];
              const shippedNum = Math.round(Number(raw === "" || raw == null ? made : raw) || 0);
              const capped = Math.min(Math.max(0, shippedNum), made);
              const waste = Math.max(0, made - capped);
              const invalid = shippedNum > made || shippedNum < 0;
              const shipPct = made > 0 ? Math.min(100, Math.round((capped / made) * 100)) : 0;

              return (
                <div
                  key={it.item_key}
                  className="rounded-xl p-3.5"
                  style={{ background: COLORS.bone, border: `1px solid ${invalid ? COLORS.rust : COLORS.border}` }}
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[13px] font-semibold" style={{ color: COLORS.ink }}>
                          {it.description}
                        </span>
                        <span
                          className="text-[10px] font-semibold uppercase tracking-wide px-1.5 py-0.5 rounded"
                          style={{
                            background: it.item_type === "set" ? COLORS.ink : COLORS.boneDim,
                            color: it.item_type === "set" ? COLORS.gold : COLORS.graphite,
                          }}
                        >
                          {it.item_type === "set" ? "Set" : "Article"}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-[11.5px]" style={{ color: COLORS.graphite }}>
                        <span>
                          Ordered{" "}
                          <strong className="tabular-nums" style={{ color: COLORS.ink }}>
                            {ordered.toLocaleString()}
                          </strong>
                        </span>
                        <span>
                          Made{" "}
                          <strong className="tabular-nums" style={{ color: COLORS.ink }}>
                            {made.toLocaleString()}
                          </strong>
                        </span>
                      </div>
                    </div>

                    <div className="flex items-end gap-3 shrink-0">
                      <div className="ship-qty-field">
                        <label className="form-label">Shipped</label>
                        <input
                          type="number"
                          min={0}
                          max={made}
                          step={1}
                          className={`form-input text-right tabular-nums${invalid ? " form-input-error" : ""}`}
                          value={raw ?? String(made)}
                          onChange={(e) => onQty(it.item_key, e.target.value)}
                        />
                      </div>
                      <div className="text-right min-w-[64px] pb-1">
                        <div className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: COLORS.graphiteLight }}>
                          Waste
                        </div>
                        <div
                          className="text-[20px] font-semibold tabular-nums leading-none mt-1"
                          style={{ color: waste > 0 ? COLORS.rust : COLORS.green }}
                        >
                          {waste.toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="h-1 rounded-full overflow-hidden mt-3" style={{ background: COLORS.boneDim }}>
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${shipPct}%`,
                        background: waste > 0 ? COLORS.gold : COLORS.green,
                        transition: "width 0.25s ease",
                      }}
                    />
                  </div>
                  {invalid && (
                    <p className="text-[11px] mt-2" style={{ color: COLORS.rust }}>
                      Shipped cannot exceed made ({made.toLocaleString()}).
                    </p>
                  )}
                </div>
              );
            })}
          </div>

          <div className="mt-4">
            <label className="form-label">Notes (optional)</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. held 2 cartons for QC"
              value={notes || ""}
              onChange={(e) => onNotes(e.target.value)}
              autoComplete="off"
            />
          </div>

          <div
            className="mt-4 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3"
            style={{ background: COLORS.ink }}
          >
            <div className="text-[12px]" style={{ color: COLORS.graphiteLight }}>
              Total ship{" "}
              <strong className="tabular-nums" style={{ color: COLORS.bone }}>
                {totals.shipped.toLocaleString()}
              </strong>
              <span className="mx-2" style={{ color: COLORS.graphite }}>
                ·
              </span>
              Waste{" "}
              <strong className="tabular-nums" style={{ color: totals.waste > 0 ? "#E8A090" : COLORS.gold }}>
                {totals.waste.toLocaleString()}
              </strong>
            </div>
            <button
              type="button"
              className="btn-primary text-[12.5px] font-semibold px-4 py-2 rounded-lg inline-flex items-center gap-2"
              style={{
                background: totals.invalid ? COLORS.graphite : COLORS.gold,
                color: COLORS.ink,
                opacity: saving ? 0.7 : 1,
              }}
              disabled={saving || totals.invalid || totals.made === 0}
              onClick={onConfirm}
            >
              <TruckIcon />
              {saving ? "Saving…" : "Mark shipped"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function HistoryCard({ ship, index, open, onToggle }) {
  const items = ship.items || [];
  const wasteTotal = items.reduce((s, it) => s + (Number(it.qty_waste) || 0), 0);
  const shippedTotal = items.reduce((s, it) => s + (Number(it.qty_shipped) || 0), 0);
  const madeTotal = items.reduce((s, it) => s + (Number(it.qty_made) || 0), 0);

  return (
    <div
      className="ship-card fade-in rounded-2xl overflow-hidden"
      style={{
        background: COLORS.card,
        border: `1px solid ${COLORS.border}`,
        animationDelay: `${index * 40}ms`,
      }}
    >
      <button type="button" className="w-full text-left px-5 py-4" onClick={onToggle}>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span
                className="text-[11px] font-bold px-2 py-0.5 rounded"
                style={{ background: COLORS.ink, color: COLORS.gold }}
              >
                ATM {ship.atm_no}
              </span>
              <span
                className="text-[10.5px] font-semibold px-2 py-0.5 rounded inline-flex items-center gap-1"
                style={{ background: COLORS.greenSoft, color: COLORS.green }}
              >
                <DoneIcon /> Shipped
              </span>
            </div>
            <div className="text-[14px] font-semibold mt-2" style={{ color: COLORS.ink }}>
              {ship.customer}
            </div>
            <div className="text-[11.5px] mt-0.5" style={{ color: COLORS.graphiteLight }}>
              {ship.bill_no ? `Bill ${ship.bill_no} · ` : ""}
              {formatDateTime(ship.shipped_at)}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <MetricChip label="Shipped" value={shippedTotal} tone="ship" />
            <MetricChip label="Waste" value={wasteTotal} tone={wasteTotal > 0 ? "waste" : "ok"} />
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{
                background: COLORS.boneDim,
                color: COLORS.graphite,
                transform: open ? "rotate(-90deg)" : "rotate(90deg)",
              }}
            >
              <ChevronIcon />
            </div>
          </div>
        </div>
        <div className="mt-3">
          <ShipProgress made={madeTotal} shipped={shippedTotal} />
        </div>
      </button>

      {open && (
        <div className="px-5 pb-5 space-y-2" style={{ borderTop: `1px solid ${COLORS.border}` }}>
          <div className="pt-3 space-y-2">
            {items.map((it) => (
              <div
                key={it.item_id || it.item_key}
                className="rounded-xl px-3.5 py-2.5 flex flex-wrap items-center justify-between gap-2"
                style={{ background: COLORS.bone }}
              >
                <div className="min-w-0">
                  <div className="text-[12.5px] font-semibold" style={{ color: COLORS.ink }}>
                    {it.description}
                  </div>
                  <div className="text-[11px] mt-0.5" style={{ color: COLORS.graphite }}>
                    Made {Number(it.qty_made).toLocaleString()} → shipped {Number(it.qty_shipped).toLocaleString()}
                  </div>
                </div>
                <div
                  className="text-[13px] font-semibold tabular-nums"
                  style={{ color: Number(it.qty_waste) > 0 ? COLORS.rust : COLORS.green }}
                >
                  Waste {Number(it.qty_waste).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
          {ship.notes ? (
            <p className="text-[12px] px-1" style={{ color: COLORS.graphiteLight }}>
              Note: {ship.notes}
            </p>
          ) : null}
        </div>
      )}
    </div>
  );
}

export default function ShipmentPage() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [tab, setTab] = useState("pending");
  const [pending, setPending] = useState([]);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [search, setSearch] = useState("");
  const [shipQtyByOrder, setShipQtyByOrder] = useState({});
  const [notesByOrder, setNotesByOrder] = useState({});
  const [expandedId, setExpandedId] = useState(null);
  const [expandedHistoryId, setExpandedHistoryId] = useState(null);
  const [savingId, setSavingId] = useState(null);
  const [actionError, setActionError] = useState("");
  const [actionOk, setActionOk] = useState("");

  const loadAll = useCallback(async () => {
    setLoading(true);
    setLoadError("");
    try {
      const [pendRes, histRes] = await Promise.all([
        apiFetch("/api/shipments/pending"),
        apiFetch("/api/shipments"),
      ]);
      if (!pendRes.ok) throw new Error(await readApiError(pendRes, "Failed to load pending shipments"));
      if (!histRes.ok) throw new Error(await readApiError(histRes, "Failed to load shipment history"));
      const pendData = await pendRes.json();
      const histData = await histRes.json();
      setPending(Array.isArray(pendData) ? pendData : []);
      setHistory(Array.isArray(histData) ? histData : []);

      setShipQtyByOrder((prev) => {
        const next = { ...prev };
        for (const order of pendData || []) {
          const id = order.order_id;
          if (!next[id]) next[id] = draftToShipState(order.draft_items);
        }
        return next;
      });

      setExpandedId((prev) => {
        if (prev && (pendData || []).some((o) => o.order_id === prev)) return prev;
        return (pendData || [])[0]?.order_id ?? null;
      });
    } catch (err) {
      setLoadError(err.message || "Failed to load shipments");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const filteredPending = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return pending;
    return pending.filter(
      (o) =>
        String(o.atm_no || "").toLowerCase().includes(q) ||
        String(o.customer || "").toLowerCase().includes(q) ||
        String(o.bill_no || "").toLowerCase().includes(q)
    );
  }, [pending, search]);

  const filteredHistory = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return history;
    return history.filter(
      (s) =>
        String(s.atm_no || "").toLowerCase().includes(q) ||
        String(s.customer || "").toLowerCase().includes(q) ||
        String(s.bill_no || "").toLowerCase().includes(q)
    );
  }, [history, search]);

  const pendingWastePreview = useMemo(() => {
    return pending.reduce((sum, order) => {
      const t = lineTotals(order.draft_items, shipQtyByOrder[order.order_id]);
      return sum + t.waste;
    }, 0);
  }, [pending, shipQtyByOrder]);

  const historyWasteTotal = useMemo(() => {
    return history.reduce(
      (sum, s) => sum + (s.items || []).reduce((a, it) => a + (Number(it.qty_waste) || 0), 0),
      0
    );
  }, [history]);

  function setShippedQty(orderId, itemKey, value) {
    setShipQtyByOrder((prev) => ({
      ...prev,
      [orderId]: {
        ...(prev[orderId] || {}),
        [itemKey]: value,
      },
    }));
  }

  function fillMax(order) {
    setShipQtyByOrder((prev) => ({
      ...prev,
      [order.order_id]: draftToShipState(order.draft_items),
    }));
  }

  async function confirmShip(order) {
    setActionError("");
    setActionOk("");
    const drafts = order.draft_items || [];
    const qtyMap = shipQtyByOrder[order.order_id] || {};
    const items = [];

    for (const it of drafts) {
      const made = Math.max(0, Math.round(Number(it.qty_made) || 0));
      const raw = qtyMap[it.item_key];
      const shipped = Math.round(Number(raw === "" || raw == null ? made : raw) || 0);
      if (shipped < 0) {
        setActionError(`${it.description}: shipped cannot be negative`);
        return;
      }
      if (shipped > made) {
        setActionError(`${it.description}: shipped (${shipped}) cannot exceed made (${made})`);
        return;
      }
      items.push({
        item_key: it.item_key,
        item_type: it.item_type,
        description: it.description,
        qty_ordered: it.qty_ordered,
        qty_made: made,
        qty_shipped: shipped,
      });
    }

    if (!items.length) {
      setActionError("Nothing to ship on this order");
      return;
    }

    setSavingId(order.order_id);
    try {
      const res = await apiFetch("/api/shipments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          order_id: order.order_id,
          notes: notesByOrder[order.order_id] || "",
          items,
        }),
      });
      if (!res.ok) throw new Error(await readApiError(res, "Failed to record shipment"));
      setActionOk(`ATM ${order.atm_no} marked shipped`);
      setExpandedId(null);
      await loadAll();
    } catch (err) {
      setActionError(err.message || "Failed to record shipment");
    } finally {
      setSavingId(null);
    }
  }

  return (
    <div className="min-h-screen w-full flex" style={{ background: COLORS.bone, fontFamily: FONT }}>
      <Sidebar mobileOpen={mobileNavOpen} onClose={() => setMobileNavOpen(false)} />

      <div className="flex-1 min-w-0">
        <div
          className="flex items-center justify-between gap-3 px-5 md:px-8 py-4 sticky top-0 z-30 backdrop-blur"
          style={{ background: `${COLORS.bone}F2`, borderBottom: `1px solid ${COLORS.border}` }}
        >
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              className="md:hidden p-2 rounded-lg btn-secondary shrink-0"
              style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}
              onClick={() => setMobileNavOpen(true)}
              aria-label="Open navigation"
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M2 4h12M2 8h12M2 12h12" stroke={COLORS.ink} strokeWidth="1.4" strokeLinecap="round" />
              </svg>
            </button>
            <div className="min-w-0">
              <h1 className="text-xl font-semibold truncate" style={{ color: COLORS.ink }}>
                Shipment
              </h1>
              <p className="text-[12px]" style={{ color: COLORS.graphiteLight }}>
                Pack → ship → waste is what stayed behind
              </p>
            </div>
          </div>
          <button
            type="button"
            className="btn-secondary text-[12px] font-semibold px-3 py-2 rounded-lg shrink-0"
            style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, color: COLORS.ink }}
            onClick={loadAll}
          >
            Refresh
          </button>
        </div>

        <div className="p-5 md:p-8 max-w-5xl mx-auto">
          {(loadError || actionError || actionOk) && (
            <div className="space-y-2 mb-5">
              {loadError && (
                <div className="rounded-xl px-4 py-3 text-[12.5px]" style={{ background: COLORS.rustSoft, color: COLORS.rust }}>
                  {loadError}
                </div>
              )}
              {actionError && (
                <div className="rounded-xl px-4 py-3 text-[12.5px]" style={{ background: COLORS.rustSoft, color: COLORS.rust }}>
                  {actionError}
                </div>
              )}
              {actionOk && (
                <div className="rounded-xl px-4 py-3 text-[12.5px] font-medium" style={{ background: COLORS.greenSoft, color: COLORS.green }}>
                  {actionOk}
                </div>
              )}
            </div>
          )}

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <MiniStat index={0} icon={<WaitingIcon />} label="Waiting" value={pending.length} sub="ready to ship" />
            <MiniStat index={1} icon={<TruckIcon />} label="Shipped" value={history.length} sub="on record" />
            <MiniStat
              index={2}
              icon={<WasteIcon />}
              label="Open waste"
              value={pendingWastePreview.toLocaleString()}
              sub="from current draft"
            />
            <MiniStat
              index={3}
              icon={<DoneIcon />}
              label="Past waste"
              value={historyWasteTotal.toLocaleString()}
              sub="from shipped orders"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3 mb-5">
            <div
              className="flex p-1 rounded-xl"
              style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}
            >
              {[
                { id: "pending", label: "Waiting", count: pending.length },
                { id: "history", label: "Shipped", count: history.length },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTab(t.id)}
                  className="px-3.5 py-2 text-[12.5px] font-semibold rounded-lg inline-flex items-center gap-2"
                  style={{
                    background: tab === t.id ? COLORS.ink : "transparent",
                    color: tab === t.id ? COLORS.bone : COLORS.graphite,
                  }}
                >
                  {t.label}
                  <span
                    className="text-[10.5px] font-bold px-1.5 py-0.5 rounded-md tabular-nums"
                    style={{
                      background: tab === t.id ? "rgba(255,255,255,0.12)" : COLORS.boneDim,
                      color: tab === t.id ? COLORS.gold : COLORS.graphite,
                    }}
                  >
                    {t.count}
                  </span>
                </button>
              ))}
            </div>
            <div className="search-wrap">
              <SearchIcon />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search ATM, customer, bill…"
              />
            </div>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="rounded-2xl h-[108px] animate-pulse"
                  style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, opacity: 1 - i * 0.15 }}
                />
              ))}
            </div>
          ) : tab === "pending" ? (
            filteredPending.length === 0 ? (
              <div
                className="rounded-2xl px-6 py-14 text-center fade-in"
                style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}
              >
                <div className="flex justify-center mb-3">
                  <EmptyBoxIcon />
                </div>
                <div className="text-[15px] font-semibold" style={{ color: COLORS.ink }}>
                  Nothing waiting to ship
                </div>
                <p className="text-[13px] mt-1.5 max-w-sm mx-auto" style={{ color: COLORS.graphite }}>
                  {search
                    ? "No matches for that search."
                    : "Invoice a completed order on the Orders page and it will show up here."}
                </p>
              </div>
            ) : (
              <div className="space-y-3.5">
                {filteredPending.map((order, i) => (
                  <PendingCard
                    key={order.order_id}
                    order={order}
                    index={i}
                    open={expandedId === order.order_id}
                    onToggle={() => setExpandedId(expandedId === order.order_id ? null : order.order_id)}
                    qtyMap={shipQtyByOrder[order.order_id] || {}}
                    notes={notesByOrder[order.order_id] || ""}
                    onNotes={(v) => setNotesByOrder((prev) => ({ ...prev, [order.order_id]: v }))}
                    onQty={(key, v) => setShippedQty(order.order_id, key, v)}
                    onShipAll={() => fillMax(order)}
                    onConfirm={() => confirmShip(order)}
                    saving={savingId === order.order_id}
                  />
                ))}
              </div>
            )
          ) : filteredHistory.length === 0 ? (
            <div
              className="rounded-2xl px-6 py-14 text-center fade-in"
              style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}
            >
              <div className="flex justify-center mb-3">
                <EmptyBoxIcon />
              </div>
              <div className="text-[15px] font-semibold" style={{ color: COLORS.ink }}>
                No shipments yet
              </div>
              <p className="text-[13px] mt-1.5" style={{ color: COLORS.graphite }}>
                {search ? "No matches for that search." : "Confirmed shipments will land here."}
              </p>
            </div>
          ) : (
            <div className="space-y-3.5">
              {filteredHistory.map((ship, i) => (
                <HistoryCard
                  key={ship.shipment_id}
                  ship={ship}
                  index={i}
                  open={expandedHistoryId === ship.shipment_id}
                  onToggle={() =>
                    setExpandedHistoryId(expandedHistoryId === ship.shipment_id ? null : ship.shipment_id)
                  }
                />
              ))}
            </div>
          )}
        </div>
      </div>

      <style>{`
        * { box-sizing: border-box; }

        @keyframes fadeInUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes growBar { from { width: 0; } }
        .fade-in { animation: fadeInUp 0.45s cubic-bezier(0.16, 1, 0.3, 1) both; }
        .ship-bar { animation: growBar 0.55s cubic-bezier(0.16, 1, 0.3, 1) both; }

        .ship-card, .stat-card, .btn-primary, .btn-secondary {
          transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease, background-color 0.2s ease;
        }
        .ship-card:hover { border-color: ${COLORS.gold} !important; }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 14px 28px -18px rgba(28,25,23,0.28); border-color: ${COLORS.gold} !important; }
        .btn-primary:hover:not(:disabled) { filter: brightness(1.06); transform: translateY(-1px); box-shadow: 0 8px 18px -8px rgba(184,135,61,0.5); }
        .btn-primary:disabled { cursor: not-allowed; filter: none; transform: none; box-shadow: none; }
        .btn-secondary:hover { border-color: ${COLORS.gold} !important; color: ${COLORS.goldDim} !important; background: ${COLORS.goldSoft}55 !important; }

        .form-label {
          font-size: 10.5px; font-weight: 600; text-transform: uppercase; letter-spacing: .03em;
          color: ${COLORS.graphite}; margin-bottom: 4px; display: block;
        }
        .form-input {
          font-family: ${FONT}; font-size: 12.5px; color: ${COLORS.ink}; background: ${COLORS.card};
          border: 1px solid ${COLORS.border}; border-radius: 8px; padding: 7px 10px; outline: none; width: 100%;
          transition: border-color .2s ease, box-shadow .2s ease;
        }
        .form-input:hover, .form-input:focus { border-color: ${COLORS.gold}; box-shadow: 0 0 0 3px ${COLORS.goldSoft}66; }
        .form-input::placeholder { color: ${COLORS.graphiteLight}; }
        .form-input-error,
        .form-input-error:hover,
        .form-input-error:focus {
          border-color: ${COLORS.rust} !important;
          box-shadow: 0 0 0 3px ${COLORS.rustSoft} !important;
        }

        .ship-qty-field { width: 108px; }
        .ship-qty-field .form-input { font-weight: 600; }

        .search-wrap { position: relative; display: inline-flex; align-items: center; }
        .search-wrap svg { position: absolute; left: 10px; color: ${COLORS.graphiteLight}; pointer-events: none; }
        .search-wrap input {
          font-family: ${FONT}; font-size: 12.5px; color: ${COLORS.ink}; background: ${COLORS.card};
          border: 1px solid ${COLORS.border}; border-radius: 8px; padding: 8px 12px 8px 30px;
          outline: none; width: 260px; transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }
        .search-wrap input::placeholder { color: ${COLORS.graphiteLight}; }
        .search-wrap input:hover, .search-wrap input:focus { border-color: ${COLORS.gold}; box-shadow: 0 0 0 3px ${COLORS.goldSoft}66; }

        button:focus-visible, input:focus-visible { outline: 2px solid ${COLORS.gold}; outline-offset: 2px; }
        .tabular-nums { font-variant-numeric: tabular-nums; }

        @media (max-width: 640px) {
          .search-wrap { width: 100%; }
          .search-wrap input { width: 100% !important; }
        }

        @media (prefers-reduced-motion: reduce) {
          .fade-in, .ship-bar, .ship-card, .stat-card, .btn-primary, .btn-secondary { animation: none !important; transition: none !important; }
        }
      `}</style>
    </div>
  );
}
