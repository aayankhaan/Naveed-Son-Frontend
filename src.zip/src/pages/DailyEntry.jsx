// ========================================
// DailyEntry.jsx
// Floor board + per-employee add data.
// Pick a Karachi date: empty → add form; has data → locked batch.
// ========================================

import { useState, useMemo, useEffect, Fragment, useCallback } from "react";
import { FONT, COLORS } from "../constants/theme";
import Sidebar from "../components/layout/Sidebar";
import MiniStat from "../components/ui/MiniStat";
import { SearchIcon } from "../components/icons/CommonIcons";
import { apiFetch } from "../lib/api";
import {
  STATION_ORDER,
  skipMap,
  previousStation,
  emptyStationTotals,
  liveStationTotals,
  liveAddonTotals,
  availableForStation,
  availableForAddon,
  describePipelineStatus,
  stationWipTotals,
  lineSelectedAddons,
  findLineAddon,
} from "../lib/productionFlow";
import {
  karachiTodayISO,
  formatKarachiDMY,
  toIsoDateOnly,
  catchUpWindow,
  missingDaysInWindow,
  addDaysISO,
} from "../lib/karachiDate";

const STATION_COLORS = {
  Cutting: COLORS.graphiteLight,
  Stitching: COLORS.gold,
  Checking: COLORS.goldDim,
  Packing: COLORS.green,
};

const STATION_SHORT = { Cutting: "Cut", Stitching: "Sti", Checking: "Che", Packing: "Pac" };
const LOOKBACK_DAYS = 31;

function initials(name) {
  if (!name) return "E";
  return name.split(" ").filter(Boolean).map((p) => p[0]).slice(0, 2).join("").toUpperCase();
}

function formatPKR(n) {
  return `PKR ${Math.round(n).toLocaleString()}`;
}

async function readApiError(res, fallback) {
  try {
    const data = await res.json();
    return data.error || fallback;
  } catch {
    return fallback;
  }
}

function emptyEntry() {
  return { orderId: null, orderLineId: null, variantId: null, addonId: null, qty: "", defects: "" };
}

function emptyDraft(targetDate) {
  return {
    targetDate: targetDate || karachiTodayISO(),
    isLeave: false,
    addingMore: false,
    entries: [emptyEntry()],
  };
}

function UsersIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <circle cx="6" cy="5.5" r="2.3" stroke="currentColor" strokeWidth="1.3" />
      <path d="M1.7 14c.6-3 2.4-4.6 4.3-4.6S10 11 10.6 14" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      <circle cx="11.5" cy="6" r="1.8" stroke="currentColor" strokeWidth="1.2" />
      <path d="M10.8 9.6c1.8.2 3 1.6 3.4 3.7" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function LayersIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M8 1.5L1.5 5 8 8.5 14.5 5 8 1.5zM1.5 8L8 11.5 14.5 8M1.5 11L8 14.5 14.5 11" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function BanknoteIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <rect x="1.5" y="4" width="13" height="8.5" rx="1.6" stroke="currentColor" strokeWidth="1.3" />
      <circle cx="8" cy="8.25" r="2" stroke="currentColor" strokeWidth="1.2" />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
      <path d="M7 1.5v11M1.5 7h11" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

function stationRate(line, station) {
  if (!line) return 0;
  const map = {
    Cutting: line.cutting_rate,
    Stitching: line.stitching_rate,
    Checking: line.checking_rate,
    Packing: line.packing_rate,
  };
  return Number(map[station]) || 0;
}

function entryRate(line, station, addonId) {
  if (addonId) {
    const ad = findLineAddon(line, addonId);
    return Number(ad?.addonRate) || 0;
  }
  return stationRate(line, station);
}

function clampQtyToHeadroom(raw, headroom) {
  if (raw === "" || raw == null) return "";
  let n = Number(raw);
  if (Number.isNaN(n) || n < 0) return "0";
  if (headroom != null) {
    if (headroom <= 0) return "";
    n = Math.min(n, headroom);
  }
  return String(n);
}

function StationPills({ line, totals, orderQty, addonTotals }) {
  const skips = skipMap(line);
  const live = totals || emptyStationTotals();
  const wip = stationWipTotals(line, live);
  const enabled = STATION_ORDER.filter((s) => !skips[s]);
  const last = enabled[enabled.length - 1];
  const addons = lineSelectedAddons(line);
  return (
    <div className="flex flex-wrap items-center gap-1">
      {STATION_ORDER.map((s, i) => {
        const skipped = skips[s];
        const qty = Number(wip[s]) || 0;
        const finishedHere = s === last;
        const over = !skipped && finishedHere && (Number(live[s]) || 0) > (Number(orderQty) || 0);
        const afterPills = addons.filter((a) => {
          const req = a.requiresStations || [];
          const lastReq = req[req.length - 1];
          return lastReq === s;
        });
        return (
          <Fragment key={s}>
            {i > 0 && <span className="text-[10px]" style={{ color: COLORS.graphiteLight }}>→</span>}
            <span
              className="text-[10px] font-semibold px-2 py-0.5 rounded"
              style={{
                background: skipped ? COLORS.boneDim : over ? COLORS.goldSoft : COLORS.card,
                color: skipped ? COLORS.graphiteLight : COLORS.ink,
                textDecoration: skipped ? "line-through" : "none",
                border: `1px solid ${COLORS.border}`,
              }}
            >
              {STATION_SHORT[s]} {skipped ? "—" : qty.toLocaleString()}
            </span>
            {afterPills.map((a) => (
              <Fragment key={a.id}>
                <span className="text-[10px]" style={{ color: COLORS.graphiteLight }}>→</span>
                <span
                  className="text-[10px] font-semibold px-2 py-0.5 rounded"
                  style={{
                    background: COLORS.goldSoft,
                    color: COLORS.ink,
                    border: `1px solid ${COLORS.border}`,
                  }}
                >
                  {a.name} {(Number(addonTotals?.[a.id]) || 0).toLocaleString()}
                </span>
              </Fragment>
            ))}
          </Fragment>
        );
      })}
    </div>
  );
}

function formContributionByVariant(employees, rowsState) {
  const map = {};
  (employees || []).forEach((emp) => {
    const row = rowsState?.[emp.id];
    if (!row || row.isLeave) return;
    row.entries.forEach((entry) => {
      if (!entry.variantId || entry.addonId) return;
      const qty = Number(entry.qty) || 0;
      if (qty <= 0) return;
      if (!map[entry.variantId]) map[entry.variantId] = emptyStationTotals();
      map[entry.variantId][emp.station] =
        (Number(map[entry.variantId][emp.station]) || 0) + qty;
    });
  });
  return map;
}

function formAddonContributionByVariant(employees, rowsState) {
  const map = {};
  (employees || []).forEach((emp) => {
    const row = rowsState?.[emp.id];
    if (!row || row.isLeave) return;
    row.entries.forEach((entry) => {
      if (!entry.variantId || !entry.addonId) return;
      const qty = Number(entry.qty) || 0;
      if (qty <= 0) return;
      if (!map[entry.variantId]) map[entry.variantId] = {};
      map[entry.variantId][entry.addonId] =
        (Number(map[entry.variantId][entry.addonId]) || 0) + qty;
    });
  });
  return map;
}

function FloorBoard({ orders, totalsForVariant, addonTotalsForVariant, onPick }) {
  const cards = useMemo(() => {
    return (orders || []).map((order) => {
      const parts = (order.lines || []).flatMap((line) =>
        (line.variants || []).map((v) => {
          const totals = totalsForVariant(v.variant_id);
          const addonTotals = addonTotalsForVariant?.(v.variant_id) || {};
          return {
            key: `${line.order_line_id}-${v.variant_id}`,
            orderId: order.order_id,
            orderLineId: line.order_line_id,
            variantId: v.variant_id,
            line,
            variant: v,
            totals,
            status: describePipelineStatus(line, totals, addonTotals),
          };
        })
      );
      return { order, parts };
    }).filter((c) => c.parts.length);
  }, [orders, totalsForVariant, addonTotalsForVariant]);

  if (!cards.length) {
    return (
      <div className="rounded-2xl p-8 text-center" style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}>
        <p className="text-[13px]" style={{ color: COLORS.graphiteLight }}>No open ATM orders yet.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {cards.map(({ order, parts }) => (
        <div key={order.order_id} className="rounded-2xl overflow-hidden" style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}>
          <div className="flex items-center justify-between gap-3 px-4 py-3" style={{ background: COLORS.boneDim, borderBottom: `1px solid ${COLORS.border}` }}>
            <div>
              <div className="text-[14px] font-semibold" style={{ color: COLORS.ink }}>
                ATM {order.atm_no} · {order.customer}
              </div>
              <div className="text-[11px] mt-0.5" style={{ color: COLORS.graphiteLight }}>
                {parts.length} part{parts.length === 1 ? "" : "s"} on the floor
              </div>
            </div>
          </div>
          <div className="divide-y" style={{ borderColor: COLORS.border }}>
            {parts.map((p) => (
              <button
                key={p.key}
                type="button"
                className="w-full text-left px-4 py-3 hover:brightness-[0.99] transition"
                style={{ background: COLORS.card }}
                onClick={() => onPick?.(p)}
              >
                <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                  <div className="min-w-0">
                    <div className="text-[13px] font-semibold truncate" style={{ color: COLORS.ink }}>
                      {p.line.article_name}
                      {p.line.dimension_name ? ` · ${p.line.dimension_name}` : ""}
                    </div>
                    <div className="text-[11.5px] mt-0.5" style={{ color: COLORS.graphite }}>
                      {p.variant.variant_name} · order {Number(p.variant.quantity || 0).toLocaleString()} pcs
                    </div>
                  </div>
                  <div className="text-[11.5px] font-semibold text-right" style={{ color: COLORS.goldDim }}>
                    {p.status}
                  </div>
                </div>
                <StationPills line={p.line} totals={p.totals} orderQty={p.variant.quantity} />
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function LockedBatch({ date, day }) {
  return (
    <div className="rounded-xl px-3 py-3 space-y-2" style={{ background: COLORS.bone, border: `1px solid ${COLORS.border}` }}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="text-[13px] font-semibold" style={{ color: COLORS.ink }}>
          {formatKarachiDMY(date)}
          {day.status === "leave" ? (
            <span className="font-normal" style={{ color: COLORS.rust }}> · no work / leave</span>
          ) : (
            <span className="font-normal" style={{ color: COLORS.graphite }}>
              {" "}· {Number(day.qty || 0).toLocaleString()} pcs
            </span>
          )}
        </div>
        <span className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: COLORS.graphiteLight }}>
          This batch is locked
        </span>
      </div>
      {day.status === "work" && (day.lines || []).map((ln) => (
        <div key={ln.log_id} className="text-[11.5px]" style={{ color: COLORS.graphite }}>
          {(ln.atm_no ? `ATM ${ln.atm_no}` : "ATM")}
          {ln.article_name ? ` · ${ln.article_name}` : ""}
          {ln.variant_name ? ` · ${ln.variant_name}` : ""}
          {ln.addon_id ? " · add-on" : ln.station ? ` · ${ln.station}` : ""}
          {" · "}
          {Number(ln.quantity || 0).toLocaleString()} pcs
          {ln.defects ? ` · ${ln.defects} def` : ""}
        </div>
      ))}
      <p className="text-[11px]" style={{ color: COLORS.graphiteLight }}>
        Saved · locked (editing would break stock). You can still add more pcs below.
      </p>
    </div>
  );
}

export default function DailyEntryPage() {
  const karachiToday = karachiTodayISO();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [stationFilter, setStationFilter] = useState("All stations");
  const [activeEmpId, setActiveEmpId] = useState(null);
  const [floorPick, setFloorPick] = useState(null);

  const [employees, setEmployees] = useState([]);
  const [orders, setOrders] = useState([]);
  const [fullTotals, setFullTotals] = useState({});
  const [fullAddonTotals, setFullAddonTotals] = useState({});
  /** EMP-id → { dates: { ISO: { status, qty, lines } } } */
  const [employeeDays, setEmployeeDays] = useState({});

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [rows, setRows] = useState({});

  const refreshFullTotals = useCallback(async () => {
    try {
      const res = await apiFetch("/api/production/station-totals");
      if (!res.ok) return null;
      const data = await res.json();
      if (data && data.stations && typeof data.stations === "object") {
        setFullTotals(data.stations);
        setFullAddonTotals(data.addons || {});
      } else {
        // legacy shape: flat variant → stations
        const { stations: _s, addons: a, ...rest } = data || {};
        setFullTotals(rest);
        setFullAddonTotals(a || {});
      }
      return data;
    } catch (err) {
      console.error(err);
      return null;
    }
  }, []);

  const loadEmployeeDays = useCallback(async (emps, { keepDrafts = false } = {}) => {
    const today = karachiTodayISO();
    let from = addDaysISO(today, -(LOOKBACK_DAYS - 1));
    for (const emp of emps) {
      if (emp.joiningDate && emp.joiningDate > from && emp.joiningDate <= today) {
        // keep from as lookback; joining only clamps min date on picker
      }
      if (emp.joiningDate && emp.joiningDate < from) {
        /* lookback wins for API range */
      }
    }
    const res = await apiFetch(`/api/production/employee-days?from=${from}&to=${today}`);
    if (!res.ok) throw new Error(await readApiError(res, "Failed to load employee days"));
    const data = await res.json();

    const map = {};
    emps.forEach((emp) => {
      map[emp.id] = { dates: {} };
    });
    (Array.isArray(data) ? data : []).forEach((row) => {
      const id = `EMP-${row.employee_id}`;
      map[id] = { dates: row.dates || {} };
    });
    setEmployeeDays(map);

    if (!keepDrafts) {
      setRows((prev) => {
        const next = {};
        emps.forEach((emp) => {
          const prevDate = prev[emp.id]?.targetDate;
          const date =
            prevDate && prevDate <= today && (!emp.joiningDate || prevDate >= emp.joiningDate)
              ? prevDate
              : today;
          next[emp.id] = emptyDraft(date);
        });
        return next;
      });
    }
    return map;
  }, []);

  useEffect(() => {
    let cancelled = false;
    async function loadBase() {
      setLoading(true);
      setLoadError("");
      try {
        const [empRes, ordRes] = await Promise.all([
          apiFetch("/api/employees"),
          apiFetch("/api/orders"),
        ]);
        if (!empRes.ok) throw new Error(await readApiError(empRes, "Failed to load employees"));
        if (!ordRes.ok) throw new Error(await readApiError(ordRes, "Failed to load orders"));
        const [empData, ordData] = await Promise.all([empRes.json(), ordRes.json()]);
        if (cancelled) return;
        const today = karachiTodayISO();
        const emps = (Array.isArray(empData) ? empData : []).map((e) => ({
          id: `EMP-${e.e_id}`,
          numericId: e.e_id,
          name: e.full_name,
          station: e.station || "Stitching",
          image: e.image_link,
          joiningDate: toIsoDateOnly(e.joining_date) || null,
        }));
        setEmployees(emps);
        // Shipped orders are closed — no further daily production on them
        setOrders(
          (Array.isArray(ordData) ? ordData : []).filter((o) => o.payment_status !== "shipped")
        );
        const blank = {};
        emps.forEach((emp) => {
          blank[emp.id] = emptyDraft(today);
        });
        setRows(blank);
        await Promise.all([refreshFullTotals(), loadEmployeeDays(emps)]);
      } catch (err) {
        console.error(err);
        if (!cancelled) setLoadError(err.message || "Could not load data");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    loadBase();
    return () => { cancelled = true; };
  }, [refreshFullTotals, loadEmployeeDays]);

  const orderById = (id) => orders.find((o) => o.order_id === Number(id)) || null;

  const formByVariant = useMemo(
    () => formContributionByVariant(employees, rows),
    [employees, rows]
  );
  const formAddonByVariant = useMemo(
    () => formAddonContributionByVariant(employees, rows),
    [employees, rows]
  );

  const totalsForVariant = useCallback(
    (variantId) => liveStationTotals(fullTotals[variantId], formByVariant[variantId]),
    [fullTotals, formByVariant]
  );
  const addonTotalsForVariant = useCallback(
    (variantId) => liveAddonTotals(fullAddonTotals[variantId], formAddonByVariant[variantId]),
    [fullAddonTotals, formAddonByVariant]
  );

  useEffect(() => {
    setRows((prev) => {
      const currentForm = formContributionByVariant(employees, prev);
      const currentAddonForm = formAddonContributionByVariant(employees, prev);
      let changed = false;
      const next = { ...prev };
      for (const emp of employees) {
        const row = next[emp.id];
        if (!row || row.isLeave) continue;
        let rowChanged = false;
        const entries = row.entries.map((entry) => {
          if (!entry.variantId || !entry.orderId || !entry.orderLineId) return entry;
          const order = orders.find((o) => o.order_id === Number(entry.orderId));
          const line = order?.lines?.find((l) => l.order_line_id === Number(entry.orderLineId));
          if (!line) return entry;

          if (entry.addonId) {
            const addon = findLineAddon(line, entry.addonId);
            if (!addon) {
              if (entry.qty === "" || entry.qty == null) return entry;
              rowChanged = true;
              return { ...entry, addonId: null, qty: "" };
            }
            const formWithout = { ...(currentAddonForm[entry.variantId] || {}) };
            const q = Number(entry.qty) || 0;
            formWithout[entry.addonId] = Math.max(0, (Number(formWithout[entry.addonId]) || 0) - q);
            const liveAddons = liveAddonTotals(fullAddonTotals[entry.variantId], formWithout);
            const stationLive = liveStationTotals(fullTotals[entry.variantId], currentForm[entry.variantId]);
            const headroom = availableForAddon(
              line,
              addon,
              stationLive,
              Number(liveAddons[entry.addonId]) || 0
            );
            const capped = clampQtyToHeadroom(entry.qty, headroom);
            if (capped !== String(entry.qty ?? "")) {
              rowChanged = true;
              return { ...entry, qty: capped };
            }
            return entry;
          }

          if (skipMap(line)[emp.station]) {
            if (entry.qty === "" || entry.qty == null) return entry;
            rowChanged = true;
            return { ...entry, qty: "" };
          }
          const formWithoutThis = { ...emptyStationTotals(), ...(currentForm[entry.variantId] || {}) };
          const q = Number(entry.qty) || 0;
          formWithoutThis[emp.station] = Math.max(0, (Number(formWithoutThis[emp.station]) || 0) - q);
          const headroom = availableForStation(
            line,
            emp.station,
            liveStationTotals(fullTotals[entry.variantId], formWithoutThis),
            liveAddonTotals(fullAddonTotals[entry.variantId], currentAddonForm[entry.variantId])
          );
          if (headroom == null) return entry;
          const capped = clampQtyToHeadroom(entry.qty, headroom);
          if (capped !== String(entry.qty ?? "")) {
            rowChanged = true;
            return { ...entry, qty: capped };
          }
          return entry;
        });
        if (rowChanged) {
          changed = true;
          next[emp.id] = { ...row, entries };
        }
      }
      return changed ? next : prev;
    });
  }, [employees, orders, fullTotals, fullAddonTotals]);

  const filteredEmployees = useMemo(() => {
    return employees.filter((emp) => {
      if (stationFilter !== "All stations" && emp.station !== stationFilter) return false;
      const q = search.toLowerCase();
      if (!q) return true;
      return emp.name.toLowerCase().includes(q) || emp.station.toLowerCase().includes(q) || String(emp.numericId).includes(q);
    });
  }, [employees, search, stationFilter]);

  const stats = useMemo(() => {
    let entriesCount = 0;
    let totalQty = 0;
    let totalPayout = 0;
    let onLeave = 0;
    employees.forEach((emp) => {
      const row = rows[emp.id];
      const dayToday = employeeDays[emp.id]?.dates?.[karachiToday];
      if (dayToday?.status === "leave" || row?.isLeave) onLeave += 1;
      if (!row || row.isLeave) return;
      row.entries.forEach((entry) => {
        const qty = Number(entry.qty) || 0;
        if (!entry.orderId || qty <= 0) return;
        entriesCount += 1;
        totalQty += qty;
        const order = orderById(entry.orderId);
        const line = order?.lines?.find((l) => l.order_line_id === Number(entry.orderLineId));
        totalPayout += Math.round(qty * entryRate(line, emp.station, entry.addonId));
      });
    });
    return { entriesCount, totalQty, totalPayout, onLeave, atmCount: orders.length };
  }, [employees, rows, orders, employeeDays, karachiToday]);

  function patchRow(empId, patch) {
    setRows((prev) => ({ ...prev, [empId]: { ...prev[empId], ...patch } }));
  }

  function setEmpDate(empId, iso) {
    const emp = employees.find((e) => e.id === empId);
    let date = iso || karachiToday;
    if (date > karachiToday) date = karachiToday;
    if (emp?.joiningDate && date < emp.joiningDate) date = emp.joiningDate;
    setRows((prev) => ({
      ...prev,
      [empId]: emptyDraft(date),
    }));
  }

  function patchEntry(empId, index, patch) {
    setRows((prev) => {
      const row = prev[empId] || emptyDraft(karachiToday);
      return {
        ...prev,
        [empId]: {
          ...row,
          entries: row.entries.map((e, i) => (i === index ? { ...e, ...patch } : e)),
        },
      };
    });
  }

  function addEntry(empId, preset = null) {
    setRows((prev) => {
      const row = prev[empId] || emptyDraft(karachiToday);
      const nextEntry = preset
        ? {
            orderId: preset.orderId,
            orderLineId: preset.orderLineId,
            variantId: preset.variantId,
            addonId: preset.addonId || null,
            qty: "",
            defects: "",
          }
        : emptyEntry();
      const entries = row.entries;
      const onlyEmpty =
        entries.length === 1 &&
        !entries[0].orderId &&
        !entries[0].qty;
      return {
        ...prev,
        [empId]: {
          ...row,
          isLeave: false,
          addingMore: true,
          entries: onlyEmpty ? [nextEntry] : [...entries, nextEntry],
        },
      };
    });
  }

  function removeEntry(empId, index) {
    setRows((prev) => {
      const row = prev[empId];
      if (!row) return prev;
      const entries = row.entries.filter((_, i) => i !== index);
      return { ...prev, [empId]: { ...row, entries: entries.length ? entries : [emptyEntry()] } };
    });
  }

  function handleFloorPick(part) {
    setFloorPick(part);
    if (!activeEmpId) return;
    const row = rows[activeEmpId];
    const day = employeeDays[activeEmpId]?.dates?.[row?.targetDate || karachiToday];
    const locked = Boolean(day);
    if (locked && !row?.addingMore) {
      addEntry(activeEmpId, {
        orderId: part.orderId,
        orderLineId: part.orderLineId,
        variantId: part.variantId,
      });
      return;
    }
    addEntry(activeEmpId, {
      orderId: part.orderId,
      orderLineId: part.orderLineId,
      variantId: part.variantId,
    });
  }

  function openEmployee(empId) {
    setActiveEmpId(empId);
    setRows((prev) => {
      const row = prev[empId] || emptyDraft(karachiToday);
      return { ...prev, [empId]: { ...row, targetDate: row.targetDate || karachiToday } };
    });
    if (floorPick) {
      addEntry(empId, {
        orderId: floorPick.orderId,
        orderLineId: floorPick.orderLineId,
        variantId: floorPick.variantId,
      });
    }
  }

  async function handleSave() {
    setSaving(true);
    setSaveError("");
    setSavedSuccess(false);
    try {
      const byDateAppend = {};
      const leaveByDate = {};

      for (const emp of employees) {
        const row = rows[emp.id];
        if (!row) continue;
        const date = toIsoDateOnly(row.targetDate) || karachiToday;
        const already = employeeDays[emp.id]?.dates?.[date]?.status;

        if (row.isLeave) {
          if (already === "leave") continue;
          if (already === "work") {
            setSaveError(`${emp.name}: ${formatKarachiDMY(date)} already has saved work (locked)`);
            setSaving(false);
            return;
          }
          if (!leaveByDate[date]) leaveByDate[date] = [];
          leaveByDate[date].push(emp.numericId);
          continue;
        }

        // Only save drafts when day is empty OR user opened “Add more”
        if (already && !row.addingMore) continue;

        for (const entry of row.entries) {
          const qty = Number(entry.qty) || 0;
          const defects = Number(entry.defects) || 0;
          if (qty <= 0 && defects <= 0) continue;
          if (!entry.orderId || !entry.orderLineId || !entry.variantId) {
            setSaveError(`${emp.name}: select ATM, item, and variant for every qty entry`);
            setSaving(false);
            return;
          }
          const order = orderById(entry.orderId);
          const line = order?.lines?.find((l) => l.order_line_id === Number(entry.orderLineId));
          if (line && !entry.addonId && skipMap(line)[emp.station]) {
            setSaveError(`${emp.name}: ${emp.station} is skipped on that order part`);
            setSaving(false);
            return;
          }
          if (entry.addonId && line && !findLineAddon(line, entry.addonId)) {
            setSaveError(`${emp.name}: that add-on is not on the selected order part`);
            setSaving(false);
            return;
          }
          if (!byDateAppend[date]) byDateAppend[date] = [];
          byDateAppend[date].push({
            employee_id: emp.numericId,
            is_leave: false,
            order_id: Number(entry.orderId),
            order_line_id: Number(entry.orderLineId),
            variant_id: entry.variantId,
            quantity: qty,
            defects,
            addon_id: entry.addonId || null,
          });
        }
      }

      const hasAppend = Object.values(byDateAppend).some((e) => e.length);
      const hasLeave = Object.values(leaveByDate).some((e) => e.length);
      if (!hasAppend && !hasLeave) {
        setSaveError("Nothing new to save — pick a date with no data, or Add more on a locked day");
        setSaving(false);
        return;
      }

      for (const emp of employees) {
        const row = rows[emp.id];
        if (!row || row.isLeave) continue;
        for (const entry of row.entries) {
          const qty = Number(entry.qty) || 0;
          if (!entry.variantId || qty <= 0) continue;
          const order = orderById(entry.orderId);
          const line = order?.lines?.find((l) => l.order_line_id === Number(entry.orderLineId));
          if (!line) continue;
          const live = liveStationTotals(fullTotals[entry.variantId], formByVariant[entry.variantId]);
          const liveAddons = liveAddonTotals(fullAddonTotals[entry.variantId], formAddonByVariant[entry.variantId]);

          if (entry.addonId) {
            const addon = findLineAddon(line, entry.addonId);
            if (!addon) continue;
            const done = Number(liveAddons[entry.addonId]) || 0;
            const requires = addon.requiresStations || ["Cutting", "Stitching"];
            let maxUp = Infinity;
            for (const s of requires) {
              if (skipMap(line)[s]) continue;
              maxUp = Math.min(maxUp, Number(live[s]) || 0);
            }
            if (Number.isFinite(maxUp) && done > maxUp) {
              setSaveError(
                `${addon.name} (${done.toLocaleString()}) cannot exceed finished prerequisites (${maxUp.toLocaleString()}).`
              );
              setSaving(false);
              return;
            }
            continue;
          }

          const prev = previousStation(line, emp.station);
          if (prev) {
            const upstream = Number(live[prev]) || 0;
            const here = Number(live[emp.station]) || 0;
            if (here > upstream) {
              setSaveError(
                `${emp.station} (${here.toLocaleString()}) cannot exceed ${prev} (${upstream.toLocaleString()}). More upstream first — over-order is OK.`
              );
              setSaving(false);
              return;
            }
          }
          const hereQty = Number(live[emp.station]) || 0;
          for (const ad of lineSelectedAddons(line)) {
            if ((ad.afterStation || "Checking") !== emp.station) continue;
            const addonDone = Number(liveAddons[ad.id]) || 0;
            if (hereQty > addonDone) {
              setSaveError(
                `${emp.station} (${hereQty.toLocaleString()}) needs more ${ad.name} first (${addonDone.toLocaleString()} done).`
              );
              setSaving(false);
              return;
            }
          }
        }
      }

      for (const [work_date, ids] of Object.entries(leaveByDate)) {
        const res = await apiFetch("/api/production", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            work_date,
            replace_all: false,
            replace_employee_ids: ids,
            entries: ids.map((id) => ({ employee_id: id, is_leave: true })),
          }),
        });
        if (!res.ok) {
          setSaveError(await readApiError(res, "Failed to save leave"));
          return;
        }
      }

      for (const [work_date, entries] of Object.entries(byDateAppend)) {
        if (!entries.length) continue;
        const res = await apiFetch("/api/production", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            work_date,
            append: true,
            replace_all: false,
            entries,
          }),
        });
        if (!res.ok) {
          setSaveError(await readApiError(res, "Failed to save production"));
          return;
        }
      }

      const [ordRes] = await Promise.all([
        apiFetch("/api/orders"),
        refreshFullTotals(),
      ]);
      if (ordRes.ok) {
        const ordData = await ordRes.json();
        setOrders(
          (Array.isArray(ordData) ? ordData : []).filter((o) => o.payment_status !== "shipped")
        );
      }
      await loadEmployeeDays(employees, { keepDrafts: false });
      setSavedSuccess(true);
    } catch (err) {
      console.error(err);
      setSaveError("Could not reach the server");
    } finally {
      setSaving(false);
    }
  }

  function renderEntryForm(emp, row) {
    return (
      <div className="space-y-3">
        {row.entries.map((entry, ei) => {
          const order = orderById(entry.orderId);
          const lines = order?.lines || [];
          const line = lines.find((l) => l.order_line_id === Number(entry.orderLineId));
          const variants = line?.variants || [];
          const variant = variants.find((v) => v.variant_id === entry.variantId);
          const lineAddons = lineSelectedAddons(line);
          const selectedAddon = entry.addonId ? findLineAddon(line, entry.addonId) : null;
          const isAddonWork = Boolean(selectedAddon);
          const rate = entryRate(line, emp.station, entry.addonId);
          const qty = Number(entry.qty) || 0;
          const skips = skipMap(line);
          const stationSkipped = Boolean(line && !isAddonWork && skips[emp.station]);
          const live = entry.variantId ? totalsForVariant(entry.variantId) : emptyStationTotals();
          const liveAddons = entry.variantId ? addonTotalsForVariant(entry.variantId) : {};

          let headroom = null;
          let isFirstStation = false;
          if (line && entry.variantId && isAddonWork) {
            const formWithout = { ...(formAddonByVariant[entry.variantId] || {}) };
            if (qty > 0) {
              formWithout[entry.addonId] = Math.max(0, (Number(formWithout[entry.addonId]) || 0) - qty);
            }
            const addonsExcluding = liveAddonTotals(fullAddonTotals[entry.variantId], formWithout);
            headroom = availableForAddon(
              line,
              selectedAddon,
              live,
              Number(addonsExcluding[entry.addonId]) || 0
            );
          } else if (line && entry.variantId) {
            const formWithoutThis = { ...(formByVariant[entry.variantId] || emptyStationTotals()) };
            if (qty > 0) {
              formWithoutThis[emp.station] = Math.max(
                0,
                (Number(formWithoutThis[emp.station]) || 0) - qty
              );
            }
            const totalsExcludingRow = liveStationTotals(fullTotals[entry.variantId], formWithoutThis);
            headroom = availableForStation(line, emp.station, totalsExcludingRow, liveAddons);
            isFirstStation = previousStation(line, emp.station) == null
              && !lineAddons.some((a) => (a.afterStation || "Checking") === emp.station);
          }

          const blocked = stationSkipped || headroom === 0;
          const needHint = isAddonWork
            ? `Need ${(selectedAddon.requiresStations || []).join(" + ") || "upstream"}`
            : `Need ${previousStation(line, emp.station)
              || lineAddons.find((a) => (a.afterStation || "Checking") === emp.station)?.name
              || "upstream"}`;

          return (
            <div key={ei} className="rounded-xl p-3 space-y-3" style={{ background: COLORS.bone, border: `1px solid ${COLORS.border}` }}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="form-label">ATM</label>
                  <select
                    className="form-input"
                    value={entry.orderId ?? ""}
                    onChange={(e) => patchEntry(emp.id, ei, {
                      orderId: e.target.value ? Number(e.target.value) : null,
                      orderLineId: null,
                      variantId: null,
                      addonId: null,
                    })}
                  >
                    <option value="">Select ATM…</option>
                    {orders.map((o) => (
                      <option key={o.order_id} value={o.order_id}>{o.atm_no} · {o.customer}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="form-label">Item / part</label>
                  <select
                    className="form-input"
                    value={entry.orderLineId ?? ""}
                    disabled={!order}
                    onChange={(e) => patchEntry(emp.id, ei, {
                      orderLineId: e.target.value ? Number(e.target.value) : null,
                      variantId: null,
                      addonId: null,
                    })}
                  >
                    <option value="">Select part…</option>
                    {lines.map((l) => {
                      const hasAddons = lineSelectedAddons(l).length > 0;
                      const skippedForStation = !hasAddons && skipMap(l)[emp.station];
                      return (
                        <option key={l.order_line_id} value={l.order_line_id} disabled={skippedForStation}>
                          {l.article_name}{l.dimension_name ? ` · ${l.dimension_name}` : ""}{skippedForStation ? " (skipped)" : ""}
                        </option>
                      );
                    })}
                  </select>
                </div>
                <div>
                  <label className="form-label">Design / variant</label>
                  <select
                    className="form-input"
                    value={entry.variantId ?? ""}
                    disabled={!line}
                    onChange={(e) => patchEntry(emp.id, ei, {
                      variantId: e.target.value || null,
                      qty: "",
                    })}
                  >
                    <option value="">Select…</option>
                    {variants.map((v) => (
                      <option key={v.variant_id} value={v.variant_id}>
                        {v.variant_name} · order {Number(v.quantity || 0).toLocaleString()}
                      </option>
                    ))}
                  </select>
                </div>
                {lineAddons.length > 0 && (
                  <div className="sm:col-span-2">
                    <label className="form-label">Work type</label>
                    <select
                      className="form-input"
                      value={entry.addonId || ""}
                      disabled={!line}
                      onChange={(e) => patchEntry(emp.id, ei, {
                        addonId: e.target.value || null,
                        qty: "",
                      })}
                    >
                      <option value="">{emp.station} station work</option>
                      {lineAddons.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.name} (add-on) · {formatPKR(a.addonRate)}/pc
                        </option>
                      ))}
                    </select>
                    <p className="text-[10.5px] mt-1" style={{ color: COLORS.graphiteLight }}>
                      Pick <strong style={{ color: COLORS.ink }}>{lineAddons.map((a) => a.name).join(" / ")}</strong>
                      {" "}to pay this employee for add-on work (any station can log it after prerequisites).
                    </p>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="form-label">
                      Qty
                      {isFirstStation && !isAddonWork
                        ? " · can exceed order"
                        : headroom != null
                          ? ` · max ${headroom.toLocaleString()}`
                          : ""}
                    </label>
                    <input
                      type="number"
                      min="0"
                      max={headroom != null ? headroom : undefined}
                      step="1"
                      className="form-input"
                      value={blocked ? "" : entry.qty}
                      disabled={blocked || !entry.variantId}
                      onChange={(e) => patchEntry(emp.id, ei, {
                        qty: clampQtyToHeadroom(e.target.value, headroom),
                      })}
                      placeholder={headroom === 0 ? needHint : "0"}
                      style={
                        blocked
                          ? { background: COLORS.boneDim, color: COLORS.graphiteLight }
                          : undefined
                      }
                    />
                  </div>
                  <div>
                    <label className="form-label">Defects</label>
                    <input
                      type="number"
                      min="0"
                      className="form-input"
                      value={entry.defects}
                      disabled={blocked}
                      onChange={(e) => patchEntry(emp.id, ei, { defects: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-[11px]" style={{ color: COLORS.graphiteLight }}>
                  {stationSkipped ? (
                    <span style={{ color: COLORS.rust }}>{emp.station} skipped — pick add-on work type if available</span>
                  ) : headroom === 0 ? (
                    <span style={{ color: COLORS.rust }}>{needHint}</span>
                  ) : (
                    <span>
                      {isAddonWork ? `${selectedAddon.name} · ` : ""}
                      Rate {formatPKR(rate)} · {formatPKR(qty * rate)}
                    </span>
                  )}
                </div>
                {row.entries.length > 1 && (
                  <button type="button" className="text-[11px] font-semibold" style={{ color: COLORS.rust }} onClick={() => removeEntry(emp.id, ei)}>
                    Remove line
                  </button>
                )}
              </div>

              {line && entry.variantId && (
                <div className="pt-1">
                  <StationPills
                    line={line}
                    totals={live}
                    orderQty={variant?.quantity ?? line.quantity}
                    addonTotals={liveAddons}
                  />
                  <p className="text-[11px] mt-1.5" style={{ color: COLORS.goldDim }}>
                    {describePipelineStatus(line, live, liveAddons)}
                  </p>
                </div>
              )}
            </div>
          );
        })}

        <button
          type="button"
          className="inline-flex items-center gap-1.5 text-[12px] font-semibold px-3 py-2 rounded-lg"
          style={{ background: COLORS.goldSoft, color: COLORS.goldDim }}
          onClick={() => addEntry(emp.id, floorPick)}
        >
          <PlusIcon /> Add another line
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full flex" style={{ background: COLORS.bone, fontFamily: FONT }}>
      <Sidebar mobileOpen={mobileNavOpen} onClose={() => setMobileNavOpen(false)} />

      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-3 px-5 md:px-8 py-4 sticky top-0 z-30 backdrop-blur" style={{ background: `${COLORS.bone}F2`, borderBottom: `1px solid ${COLORS.border}` }}>
          <div className="flex items-center gap-3 min-w-0">
            <button type="button" className="md:hidden p-2 rounded-lg btn-secondary shrink-0" style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }} onClick={() => setMobileNavOpen(true)} aria-label="Open navigation">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 4h12M2 8h12M2 12h12" stroke={COLORS.ink} strokeWidth="1.4" strokeLinecap="round" /></svg>
            </button>
            <div className="min-w-0">
              <h1 className="text-xl font-semibold truncate" style={{ color: COLORS.ink }}>Production floor</h1>
              <p className="text-[12px]" style={{ color: COLORS.graphiteLight }}>
                Karachi today · {formatKarachiDMY(karachiToday)} · pick a date per employee to add or view
              </p>
            </div>
          </div>
          <button
            type="button"
            className="btn-primary text-[12.5px] font-semibold px-4 py-2 rounded-lg shrink-0"
            style={{ background: COLORS.gold, color: COLORS.ink, opacity: saving ? 0.7 : 1 }}
            disabled={saving || loading}
            onClick={handleSave}
          >
            {saving ? "Saving…" : "Save data"}
          </button>
        </div>

        <div className="p-5 md:p-8 max-w-[1400px] mx-auto">
          {loadError && (
            <div className="rounded-xl px-4 py-3 mb-5 text-[12.5px]" style={{ background: COLORS.rustSoft, color: COLORS.rust }}>{loadError}</div>
          )}
          {saveError && (
            <div className="rounded-xl px-4 py-3 mb-5 text-[12.5px]" style={{ background: COLORS.rustSoft, color: COLORS.rust }}>{saveError}</div>
          )}
          {savedSuccess && (
            <div className="rounded-xl px-4 py-3 mb-5 text-[12.5px]" style={{ background: COLORS.greenSoft || COLORS.goldSoft, color: COLORS.green }}>
              Data saved · ATM floor updated
            </div>
          )}

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <MiniStat index={0} icon={<LayersIcon />} label="ATMs on floor" value={stats.atmCount} sub="open orders" />
            <MiniStat index={1} icon={<UsersIcon />} label="Employees" value={employees.length} sub={`${stats.onLeave} leave today`} />
            <MiniStat index={2} icon={<LayersIcon />} label="Draft entries" value={stats.entriesCount} sub={`${stats.totalQty.toLocaleString()} pcs`} />
            <MiniStat index={3} icon={<BanknoteIcon />} label="Est. payout" value={formatPKR(stats.totalPayout)} sub="draft qty × rate" />
          </div>

          {loading ? (
            <div className="rounded-2xl p-12 text-center" style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}>
              <p className="text-[13px]" style={{ color: COLORS.graphiteLight }}>Loading…</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
              <section className="xl:col-span-5">
                <div className="mb-3">
                  <h2 className="text-[15px] font-semibold" style={{ color: COLORS.ink }}>ATM floor</h2>
                  <p className="text-[11.5px]" style={{ color: COLORS.graphiteLight }}>
                    Stock left at each step · updates when you save
                  </p>
                </div>
                {floorPick && (
                  <div className="rounded-xl px-3 py-2 mb-3 text-[12px]" style={{ background: COLORS.goldSoft, border: `1px solid ${COLORS.border}`, color: COLORS.ink }}>
                    Selected: <span className="font-semibold">{floorPick.line.article_name}</span>
                    {" · "}{floorPick.variant.variant_name}
                    <button type="button" className="ml-2 font-semibold" style={{ color: COLORS.rust }} onClick={() => setFloorPick(null)}>Clear</button>
                  </div>
                )}
                <FloorBoard
                  orders={orders}
                  totalsForVariant={totalsForVariant}
                  addonTotalsForVariant={addonTotalsForVariant}
                  onPick={handleFloorPick}
                />
              </section>

              <section className="xl:col-span-7">
                <div className="flex flex-wrap items-end justify-between gap-3 mb-3">
                  <div>
                    <h2 className="text-[15px] font-semibold" style={{ color: COLORS.ink }}>Add data</h2>
                    <p className="text-[11.5px]" style={{ color: COLORS.graphiteLight }}>
                      Change date → empty day = add · saved day = locked batch
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <div className="search-wrap">
                      <SearchIcon />
                      <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search employee" />
                    </div>
                    <select className="form-input" style={{ width: "auto" }} value={stationFilter} onChange={(e) => setStationFilter(e.target.value)}>
                      <option>All stations</option>
                      <option>Cutting</option>
                      <option>Stitching</option>
                      <option>Checking</option>
                      <option>Packing</option>
                    </select>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  {filteredEmployees.map((emp) => {
                    const row = rows[emp.id] || emptyDraft(karachiToday);
                    const date = row.targetDate || karachiToday;
                    const day = employeeDays[emp.id]?.dates?.[date] || null;
                    const locked = Boolean(day);
                    const stationColor = STATION_COLORS[emp.station] || COLORS.graphite;
                    const open = activeEmpId === emp.id;
                    const draftCount = row.isLeave
                      ? 0
                      : row.entries.filter((e) => (Number(e.qty) || 0) > 0).length;
                    const minDate = emp.joiningDate || addDaysISO(karachiToday, -(LOOKBACK_DAYS - 1));
                    const hintWin = catchUpWindow({
                      today: karachiToday,
                      joiningDate: emp.joiningDate,
                      daysBack: 7,
                    });
                    const missing = missingDaysInWindow(hintWin.days, employeeDays[emp.id]?.dates || {})
                      .filter((d) => d < karachiToday)
                      .slice(0, 4);

                    return (
                      <div key={emp.id} className="rounded-2xl overflow-hidden" style={{ background: COLORS.card, border: `1px solid ${open ? COLORS.gold : COLORS.border}` }}>
                        <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3" style={{ background: COLORS.boneDim }}>
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-9 h-9 rounded-full flex items-center justify-center text-[11px] font-bold shrink-0" style={{ background: COLORS.ink, color: COLORS.gold }}>
                              {initials(emp.name)}
                            </div>
                            <div className="min-w-0">
                              <div className="text-[13px] font-semibold truncate" style={{ color: COLORS.ink }}>{emp.name}</div>
                              <div className="text-[11px]" style={{ color: stationColor }}>
                                {emp.station}
                                {" · "}{formatKarachiDMY(date)}
                                {locked ? " · locked" : " · no data yet"}
                                {draftCount > 0 ? ` · +${draftCount} draft` : ""}
                              </div>
                            </div>
                          </div>
                          <button
                            type="button"
                            className="text-[12px] font-semibold px-3 py-1.5 rounded-lg"
                            style={{
                              background: open ? COLORS.ink : COLORS.gold,
                              color: open ? COLORS.gold : COLORS.ink,
                            }}
                            onClick={() => (open ? setActiveEmpId(null) : openEmployee(emp.id))}
                          >
                            {open ? "Close" : "Open"}
                          </button>
                        </div>

                        {open && (
                          <div className="p-4 space-y-4">
                            <div className="rounded-xl px-3 py-3 space-y-2" style={{ background: COLORS.goldSoft, border: `1px solid ${COLORS.border}` }}>
                              <div className="flex flex-wrap items-end gap-3">
                                <div className="min-w-[160px]">
                                  <label className="form-label">Batch date (Karachi)</label>
                                  <input
                                    type="date"
                                    className="form-input"
                                    value={date}
                                    min={minDate}
                                    max={karachiToday}
                                    onChange={(e) => setEmpDate(emp.id, e.target.value)}
                                  />
                                </div>
                                <p className="text-[12px] pb-2" style={{ color: COLORS.ink }}>
                                  Today is <span className="font-semibold">{formatKarachiDMY(karachiToday)}</span>
                                  {" · "}showing <span className="font-semibold">{formatKarachiDMY(date)}</span>
                                </p>
                              </div>
                              {missing.length > 0 && (
                                <p className="text-[11.5px]" style={{ color: COLORS.graphite }}>
                                  Hint — no data yet for{" "}
                                  {missing.map((d, i) => (
                                    <span key={d}>
                                      {i > 0 ? ", " : ""}
                                      <button
                                        type="button"
                                        className="font-semibold underline-offset-2 hover:underline"
                                        style={{ color: COLORS.goldDim }}
                                        onClick={() => setEmpDate(emp.id, d)}
                                      >
                                        {formatKarachiDMY(d)}
                                      </button>
                                    </span>
                                  ))}
                                  . Tap a date to open it.
                                </p>
                              )}
                            </div>

                            {locked && <LockedBatch date={date} day={day} />}

                            {!locked && (
                              <div className="space-y-3">
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <h3 className="text-[12px] font-semibold" style={{ color: COLORS.ink }}>
                                    No data for {formatKarachiDMY(date)} — add below
                                  </h3>
                                  <label className="flex items-center gap-1.5 text-[11.5px] font-semibold" style={{ color: COLORS.rust }}>
                                    <input
                                      type="checkbox"
                                      checked={row.isLeave}
                                      onChange={(e) => patchRow(emp.id, {
                                        isLeave: e.target.checked,
                                        entries: e.target.checked ? [emptyEntry()] : row.entries,
                                      })}
                                    />
                                    No work / leave
                                  </label>
                                </div>
                                {row.isLeave ? (
                                  <p className="text-[12.5px]" style={{ color: COLORS.graphite }}>
                                    Will mark {formatKarachiDMY(date)} as no work on Save data.
                                  </p>
                                ) : (
                                  renderEntryForm(emp, row)
                                )}
                              </div>
                            )}

                            {locked && day.status === "work" && (
                              <div className="space-y-3">
                                {!row.addingMore ? (
                                  <button
                                    type="button"
                                    className="text-[12px] font-semibold px-3 py-2 rounded-lg"
                                    style={{ background: COLORS.goldSoft, color: COLORS.goldDim }}
                                    onClick={() => patchRow(emp.id, { addingMore: true, isLeave: false, entries: [emptyEntry()] })}
                                  >
                                    Add more pcs to this day
                                  </button>
                                ) : (
                                  <>
                                    <h3 className="text-[12px] font-semibold" style={{ color: COLORS.ink }}>
                                      Add more · {formatKarachiDMY(date)}
                                    </h3>
                                    {renderEntryForm(emp, row)}
                                    <button
                                      type="button"
                                      className="text-[11px] font-semibold"
                                      style={{ color: COLORS.graphite }}
                                      onClick={() => patchRow(emp.id, { addingMore: false, entries: [emptyEntry()] })}
                                    >
                                      Cancel add more
                                    </button>
                                  </>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                  {!filteredEmployees.length && (
                    <div className="rounded-2xl p-12 text-center" style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}>
                      <p className="text-[13px]" style={{ color: COLORS.graphiteLight }}>No employees match your filters.</p>
                    </div>
                  )}
                </div>
              </section>
            </div>
          )}
        </div>
      </div>

      <style>{`
        .form-label { font-size: 10.5px; font-weight: 600; text-transform: uppercase; letter-spacing: .03em; color: ${COLORS.graphite}; margin-bottom: 4px; display: block; }
        .form-input {
          font-family: ${FONT}; font-size: 12.5px; color: ${COLORS.ink}; background: ${COLORS.card};
          border: 1px solid ${COLORS.border}; border-radius: 8px; padding: 7px 10px; outline: none; width: 100%;
        }
        .form-input:hover, .form-input:focus { border-color: ${COLORS.gold}; box-shadow: 0 0 0 3px ${COLORS.goldSoft}66; }
        .form-input:disabled { background: ${COLORS.boneDim}; color: ${COLORS.graphiteLight}; }
        .search-wrap { position: relative; display: inline-flex; align-items: center; }
        .search-wrap svg { position: absolute; left: 10px; color: ${COLORS.graphiteLight}; pointer-events: none; }
        .search-wrap input {
          font-family: ${FONT}; font-size: 12.5px; color: ${COLORS.ink}; background: ${COLORS.card};
          border: 1px solid ${COLORS.border}; border-radius: 8px; padding: 8px 12px 8px 30px; outline: none; width: 200px;
        }
        .btn-primary:hover { filter: brightness(1.06); }
      `}</style>
    </div>
  );
}
