import { useState, useMemo } from "react";
import { FONT, COLORS } from "../../constants/theme";
import { genId, emptySetArticle, formatPKR, calcSetOrderBreakdown, configPartsToOrderParts } from "../../lib/manufacturingPricing";
import ArticleCostingForm, { normalizeSetArticle } from "./ArticleCostingForm";

const STEPS = [
  { id: "basics", label: "Set info", short: "1" },
  { id: "articles", label: "Articles", short: "2" },
  { id: "configs", label: "Sizes", short: "3" },
];

function emptyPart() {
  return { setArticleId: "", measurementId: "", quantityPerSet: 1, defaultAddonIds: [] };
}
function emptyConfig() {
  return { id: genId("CONFIG"), name: "", setSellingPrice: "", parts: [emptyPart()] };
}

function StepIndicator({ current, onJump }) {
  return (
    <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto pb-1 -mx-1 px-1">
      {STEPS.map((step, i) => {
        const active = step.id === current;
        const done = STEPS.findIndex((s) => s.id === current) > i;
        return (
          <button
            key={step.id}
            type="button"
            onClick={() => onJump(step.id)}
            className="flex items-center gap-2 shrink-0 px-3 sm:px-4 py-2.5 rounded-xl transition-all"
            style={{
              background: active ? COLORS.gold : done ? COLORS.goldSoft : COLORS.card,
              border: `1px solid ${active ? COLORS.gold : COLORS.border}`,
              color: COLORS.ink,
            }}
          >
            <span className="w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-bold" style={{ background: active ? COLORS.ink : COLORS.boneDim, color: active ? COLORS.gold : COLORS.graphite }}>
              {done ? "✓" : step.short}
            </span>
            <span className="text-[12px] font-semibold">{step.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function previewConfigPrice(articles, cfg) {
  const set = { articles: articles.filter((a) => a.name?.trim()).map(normalizeSetArticle) };
  const parts = configPartsToOrderParts((cfg.parts || []).filter((p) => p.setArticleId));
  if (!parts.length) return 0;
  return calcSetOrderBreakdown(set, cfg, parts, 1).calculatedSellingPerUnit;
}

function ConfigPartRow({ part, setArticles, onChange, onRemove }) {
  const article = setArticles.find((a) => a.id === part.setArticleId);
  const measurements = article?.measurements || [];

  return (
    <div className="rounded-xl p-4 mb-3 last:mb-0" style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}>
      <div className="flex justify-between items-start gap-2 mb-3">
        <span className="text-[12px] font-semibold" style={{ color: COLORS.ink }}>{article?.name || "Pick an article"}</span>
        <button type="button" className="text-[11px] font-semibold shrink-0 px-2 py-1" style={{ color: COLORS.rust }} onClick={onRemove}>Remove</button>
      </div>
      <div className="grid grid-cols-1 gap-3">
        <div>
          <label className="form-label">Article in this set</label>
          <select className="form-input" value={part.setArticleId} onChange={(e) => onChange({ setArticleId: e.target.value, measurementId: "", defaultAddonIds: [] })}>
            <option value="">Select article…</option>
            {setArticles.filter((a) => a.name?.trim()).map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="form-label">Measurement</label>
            <select className="form-input" value={part.measurementId || ""} disabled={!article} onChange={(e) => onChange({ measurementId: e.target.value })}>
              <option value="">Select…</option>
              {measurements.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Qty per set</label>
            <input type="number" min="1" className="form-input" value={part.quantityPerSet} onChange={(e) => onChange({ quantityPerSet: Number(e.target.value) || 1 })} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function SetEditorPage({ initialSet, onSave, onCancel }) {
  const isNew = !initialSet?.id;
  const [step, setStep] = useState("basics");
  const [name, setName] = useState(initialSet?.name || "");
  const [description, setDescription] = useState(initialSet?.description || "");
  const [setArticles, setSetArticles] = useState(() =>
    initialSet?.articles?.length ? JSON.parse(JSON.stringify(initialSet.articles)) : [emptySetArticle()]
  );
  const [configurations, setConfigurations] = useState(() =>
    initialSet?.configurations?.length ? JSON.parse(JSON.stringify(initialSet.configurations)) : [emptyConfig()]
  );
  const [expandedArticleId, setExpandedArticleId] = useState(null);
  const [expandedConfigId, setExpandedConfigId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");

  const stepIndex = STEPS.findIndex((s) => s.id === step);
  const canBasics = name.trim().length > 0;
  const canArticles = setArticles.some((a) => a.name?.trim());
  const canConfigs = configurations.some((c) => c.name.trim() && c.parts.some((p) => p.setArticleId));

  const validationMsg = useMemo(() => {
    if (step === "basics" && !canBasics) return "Enter a set name to continue.";
    if (step === "articles" && !canArticles) return "Add at least one article with a name.";
    if (step === "configs" && !canConfigs) return "Add a configuration name and link at least one article part.";
    return "";
  }, [step, canBasics, canArticles, canConfigs]);

  function goNext() {
    if (step === "basics" && canBasics) setStep("articles");
    else if (step === "articles" && canArticles) setStep("configs");
  }
  function goBack() {
    if (step === "configs") setStep("articles");
    else if (step === "articles") setStep("basics");
  }

  async function handleSave() {
    if (!canBasics || !canArticles || !canConfigs || saving) return;
    setSaving(true);
    setSaveError("");
    try {
      await onSave({
        id: initialSet?.id || genId("SET"),
        name: name.trim(),
        description: description.trim(),
        articles: setArticles.filter((a) => a.name?.trim()).map(normalizeSetArticle),
        configurations: configurations.filter((c) => c.name.trim()).map((c) => ({
          ...c,
          setSellingPrice: c.setSellingPrice === "" || c.setSellingPrice == null ? null : Number(c.setSellingPrice),
          parts: c.parts.filter((p) => p.setArticleId),
        })),
      });
    } catch (err) {
      console.error(err);
      setSaveError(err?.message || "Could not save set");
    } finally {
      setSaving(false);
    }
  }

  function updateConfigPart(configId, partIndex, patch) {
    setConfigurations((current) => current.map((cfg) => {
      if (cfg.id !== configId) return cfg;
      return { ...cfg, parts: cfg.parts.map((p, pi) => (pi === partIndex ? { ...p, ...patch } : p)) };
    }));
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col" style={{ fontFamily: FONT }}>
      {/* Header */}
      <div className="sticky top-[65px] z-20 px-4 sm:px-6 py-4 backdrop-blur" style={{ background: `${COLORS.bone}F5`, borderBottom: `1px solid ${COLORS.border}` }}>
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <button type="button" className="btn-secondary p-2 rounded-lg shrink-0" style={{ border: `1px solid ${COLORS.border}` }} onClick={onCancel} aria-label="Back to sets">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M10 3L5 8l5 5" stroke={COLORS.ink} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </button>
            <div className="min-w-0 flex-1">
              <h2 className="text-[17px] sm:text-[18px] font-semibold truncate" style={{ color: COLORS.ink }}>{isNew ? "Create new set" : `Edit ${name || "set"}`}</h2>
              <p className="text-[11.5px] truncate" style={{ color: COLORS.graphiteLight }}>3 simple steps — info, articles, then size configs</p>
            </div>
          </div>
          <StepIndicator current={step} onJump={setStep} />
        </div>
      </div>

      {/* Body */}
      <div className="flex-1 px-4 sm:px-6 py-6 pb-28 max-w-3xl mx-auto w-full">
        {step === "basics" && (
          <div className="space-y-5 fade-in">
            <div className="rounded-2xl p-4 sm:p-5" style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}>
              <label className="form-label">Set name *</label>
              <input className="form-input text-[15px] py-2.5" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Duvet Set" autoFocus />
              <label className="form-label mt-4">Description</label>
              <input className="form-input" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What's in this set?" />
            </div>
          </div>
        )}

        {step === "articles" && (
          <div className="space-y-4 fade-in">
            <div className="rounded-xl px-4 py-3 text-[12px]" style={{ background: COLORS.goldSoft, border: `1px solid ${COLORS.border}`, color: COLORS.graphite }}>
              Tap an article to expand pricing. Each set article has its own wages, measurements &amp; add-ons.
            </div>
            {setArticles.map((article, i) => {
              const open = expandedArticleId === article.id;
              const labor = (Number(article.cuttingRate) || 0) + (Number(article.stitchingRate) || 0) + (Number(article.checkingRate) || 0) + (Number(article.packingRate) || 0);
              return (
                <div key={article.id} className="rounded-2xl overflow-hidden" style={{ border: `1px solid ${open ? COLORS.gold : COLORS.border}`, background: COLORS.card }}>
                  <button
                    type="button"
                    className="w-full flex items-center gap-3 px-4 py-4 text-left"
                    style={{ background: open ? COLORS.goldSoft : COLORS.card }}
                    onClick={() => setExpandedArticleId(open ? null : article.id)}
                  >
                    <span className="w-8 h-8 rounded-lg flex items-center justify-center text-[12px] font-bold shrink-0" style={{ background: COLORS.ink, color: COLORS.gold }}>{i + 1}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-[14px] font-semibold truncate" style={{ color: COLORS.ink }}>{article.name?.trim() || "Untitled article"}</div>
                      <div className="text-[11px] mt-0.5" style={{ color: COLORS.graphiteLight }}>
                        Sell {formatPKR(Number(article.sellingPrice) || 0)} · Labor {formatPKR(labor)} · {(article.measurements || []).length} measurements
                      </div>
                    </div>
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" className="shrink-0 transition-transform" style={{ transform: open ? "rotate(180deg)" : "none" }}>
                      <path d="M3.5 5.5L7 9l3.5-3.5" stroke={COLORS.graphite} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </button>
                  {open && (
                    <div className="px-2 pb-2 sm:px-3 sm:pb-3">
                      <ArticleCostingForm
                        article={article}
                        index={i}
                        embedded
                        onChange={(updated) => setSetArticles(setArticles.map((x, j) => (j === i ? updated : x)))}
                        onRemove={setArticles.length > 1 ? () => { setSetArticles(setArticles.filter((_, j) => j !== i)); setExpandedArticleId(null); } : undefined}
                        showProfitCalc
                      />
                    </div>
                  )}
                </div>
              );
            })}
            <button
              type="button"
              className="w-full py-4 rounded-2xl text-[13px] font-semibold border-2 border-dashed"
              style={{ borderColor: COLORS.boneBorder, color: COLORS.goldDim, background: COLORS.card }}
              onClick={() => {
                const next = emptySetArticle();
                setSetArticles([...setArticles, next]);
                setExpandedArticleId(next.id);
              }}
            >
              + Add another article
            </button>
          </div>
        )}

        {step === "configs" && (
          <div className="space-y-4 fade-in">
            <div className="rounded-xl px-4 py-3 text-[12px]" style={{ background: COLORS.goldSoft, border: `1px solid ${COLORS.border}`, color: COLORS.graphite }}>
              Each configuration is a size (Single, Double…). Set how many of each article go in one set — e.g. Double = 2 pillow covers.
            </div>
            {configurations.map((cfg, ci) => {
              const open = expandedConfigId === cfg.id;
              const partCount = cfg.parts.filter((p) => p.setArticleId).length;
              const calculated = previewConfigPrice(setArticles, cfg);
              const fixedPrice = cfg.setSellingPrice !== "" && cfg.setSellingPrice != null ? Number(cfg.setSellingPrice) : null;
              const priceLabel = fixedPrice != null ? formatPKR(fixedPrice) : calculated > 0 ? `~${formatPKR(calculated)}` : null;
              return (
                <div key={cfg.id} className="rounded-2xl overflow-hidden" style={{ border: `1px solid ${open ? COLORS.gold : COLORS.border}`, background: COLORS.boneDim }}>
                  <button type="button" className="w-full flex items-center gap-3 px-4 py-4 text-left" onClick={() => setExpandedConfigId(open ? null : cfg.id)}>
                    <span className="text-[14px] font-semibold flex-1" style={{ color: COLORS.ink }}>{cfg.name?.trim() || `Configuration ${ci + 1}`}</span>
                    {priceLabel && <span className="text-[11px] font-semibold shrink-0 px-2 py-1 rounded-lg" style={{ background: COLORS.goldSoft, color: COLORS.goldDim }}>{priceLabel}/set</span>}
                    <span className="text-[11px] shrink-0" style={{ color: COLORS.graphiteLight }}>{partCount} parts</span>
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" className="shrink-0" style={{ transform: open ? "rotate(180deg)" : "none" }}>
                      <path d="M3.5 5.5L7 9l3.5-3.5" stroke={COLORS.graphite} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </button>
                  {open && (
                    <div className="px-4 pb-4">
                      <label className="form-label">Configuration name *</label>
                      <input className="form-input mb-4" value={cfg.name} onChange={(e) => setConfigurations(configurations.map((c) => (c.id === cfg.id ? { ...c, name: e.target.value } : c)))} placeholder="e.g. Single, Double, King" />
                      <div className="rounded-xl p-4 mb-4" style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}>
                        <label className="form-label">Set selling price (PKR / set)</label>
                        <input
                          type="number"
                          min="0"
                          className="form-input"
                          value={cfg.setSellingPrice ?? ""}
                          onChange={(e) => setConfigurations(configurations.map((c) => (c.id === cfg.id ? { ...c, setSellingPrice: e.target.value } : c)))}
                          placeholder="Leave empty to auto-sum from parts"
                        />
                        <p className="text-[11px] mt-2" style={{ color: COLORS.graphiteLight }}>
                          {calculated > 0 ? (
                            <>Calculated from parts: <strong style={{ color: COLORS.ink }}>{formatPKR(calculated)}</strong>{fixedPrice != null && fixedPrice !== calculated ? <> · Fixed price overrides by {formatPKR(fixedPrice - calculated)}</> : null}</>
                          ) : (
                            "Add parts above to see the calculated total."
                          )}
                        </p>
                      </div>
                      {cfg.parts.map((part, pi) => (
                        <ConfigPartRow
                          key={pi}
                          part={part}
                          setArticles={setArticles}
                          onChange={(patch) => updateConfigPart(cfg.id, pi, patch)}
                          onRemove={() => setConfigurations(configurations.map((c) => (c.id === cfg.id ? { ...c, parts: c.parts.filter((_, j) => j !== pi) } : c)))}
                        />
                      ))}
                      <div className="flex flex-wrap gap-2 mt-2">
                        <button type="button" className="text-[12px] font-semibold px-3 py-2 rounded-lg" style={{ background: COLORS.goldSoft, color: COLORS.goldDim }} onClick={() => setConfigurations(configurations.map((c) => (c.id === cfg.id ? { ...c, parts: [...c.parts, emptyPart()] } : c)))}>+ Add part</button>
                        {configurations.length > 1 && (
                          <button type="button" className="text-[12px] font-semibold px-3 py-2 rounded-lg" style={{ color: COLORS.rust }} onClick={() => setConfigurations(configurations.filter((c) => c.id !== cfg.id))}>Delete configuration</button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
            <button
              type="button"
              className="w-full py-4 rounded-2xl text-[13px] font-semibold border-2 border-dashed"
              style={{ borderColor: COLORS.boneBorder, color: COLORS.goldDim, background: COLORS.card }}
              onClick={() => { const c = emptyConfig(); setConfigurations([...configurations, c]); setExpandedConfigId(c.id); }}
            >
              + Add configuration (Single, Double…)
            </button>
          </div>
        )}

        {(validationMsg || saveError) && (
          <p className="text-[12px] mt-4 text-center" style={{ color: COLORS.rust }}>{saveError || validationMsg}</p>
        )}
      </div>

      {/* Sticky footer — aligned to main content, centered buttons */}
      <div
        className="fixed bottom-0 inset-x-0 z-30 md:left-64 backdrop-blur"
        style={{ background: `${COLORS.bone}F8`, borderTop: `1px solid ${COLORS.border}` }}
      >
        <div className="max-w-3xl mx-auto w-full px-4 sm:px-6 py-3 sm:py-4">
          {saveError && stepIndex === STEPS.length - 1 && (
            <p className="text-[12px] text-center mb-2" style={{ color: COLORS.rust }}>{saveError}</p>
          )}
          <div className="mx-auto flex w-full max-w-sm flex-col-reverse gap-2.5 sm:max-w-none sm:flex-row sm:items-center sm:justify-center sm:gap-3">
            {stepIndex > 0 ? (
              <button type="button" className="btn-secondary w-full sm:w-auto sm:min-w-[7.5rem] text-[13px] font-semibold px-6 py-3 rounded-xl" style={{ border: `1px solid ${COLORS.border}` }} onClick={goBack} disabled={saving}>Back</button>
            ) : (
              <button type="button" className="btn-secondary w-full sm:w-auto sm:min-w-[7.5rem] text-[13px] font-semibold px-6 py-3 rounded-xl" style={{ border: `1px solid ${COLORS.border}` }} onClick={onCancel} disabled={saving}>Cancel</button>
            )}
            {stepIndex < STEPS.length - 1 ? (
              <button
                type="button"
                className="btn-primary w-full sm:w-auto sm:min-w-[9rem] text-[13px] font-semibold px-6 py-3 rounded-xl"
                style={{ background: COLORS.gold, color: COLORS.ink, opacity: (step === "basics" ? canBasics : canArticles) ? 1 : 0.5 }}
                disabled={step === "basics" ? !canBasics : !canArticles}
                onClick={goNext}
              >
                Continue
              </button>
            ) : (
              <button
                type="button"
                className="btn-primary w-full sm:w-auto sm:min-w-[9rem] text-[13px] font-semibold px-6 py-3 rounded-xl"
                style={{ background: COLORS.gold, color: COLORS.ink, opacity: canConfigs && !saving ? 1 : 0.5 }}
                disabled={!canConfigs || saving}
                onClick={handleSave}
              >
                {saving ? "Saving…" : "Save set"}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
