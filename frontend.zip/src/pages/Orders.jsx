// ========================================
// Orders.jsx
// Order pipeline by ATM group: packing progress per line, an order detail
// modal, invoice generation (screen preview + PDF via InvoiceDocument),
// and an add-order form.
// ========================================

import { useState, useMemo, useEffect } from "react";
import { pdf } from "@react-pdf/renderer";
import InvoiceDocument from "./InvoiceDocument";
import { FONT, COLORS } from "../constants/theme";
import Sidebar from "../components/layout/Sidebar";
import MiniStat from "../components/ui/MiniStat";
import { SearchIcon, ChevronIcon, CloseIcon } from "../components/icons/CommonIcons";

function formatPKR(n) {
  return `PKR ${Math.round(n).toLocaleString()}`;
}

const ORDER_GROUPS_SEED = [
  {
    id: "ATM-4431",
    atmNo: "4431",
    customer: "ZEEMAN",
    date: "16-Jul-26",
    notes: "Single: 5,502 · Double: 6,402 · Total: 11,904 sets",
    lines: [
      {
        orderId: "10897",
        article: "Duvet Cover Set",
        articleNo: "—",
        size: "Single",
        dimensions: "140x200 · 60x70",
        packPerCtn: 6,
        quantity: 5502,
        readyQuantity: 5502,
        netWeight: 4.26,
        grossWeight: 5.45,
        cartonSize: "47x35x14",
        cbm: 21,
        colors: [
          { design: "Oil Green", barcode: "8720956911497" },
          { design: "Café Crème", barcode: "8720956911480" },
          { design: "Iron Gate", barcode: "8720956911473" },
          { design: "Stripe Sand", barcode: "8720956911466" },
          { design: "Irish Cream", barcode: "8720956911442" },
          { design: "Silver Grey", barcode: "8720956911459" },
        ],
      },
      {
        orderId: "10898",
        article: "Duvet Cover Set",
        articleNo: "—",
        size: "Double",
        dimensions: "200x200 · 60x70+2",
        packPerCtn: 6,
        quantity: 3804,
        readyQuantity: 3804,
        netWeight: 4.18,
        grossWeight: 4.982,
        cartonSize: "47x35x11.5",
        cbm: 12,
        colors: [
          { design: "Oil Green", barcode: "8720956911558" },
          { design: "Café Crème", barcode: "8720956911541" },
          { design: "Iron Gate", barcode: "8720956911534" },
          { design: "Stripe Sand", barcode: "8720956911527" },
          { design: "Irish Cream", barcode: "8720956911503" },
          { design: "Silver Grey", barcode: "8720956911510" },
        ],
      },
      {
        orderId: "10899",
        article: "Duvet Cover Set",
        articleNo: "—",
        size: "Double",
        dimensions: "240x220 · 60x70+2",
        packPerCtn: 6,
        quantity: 6402,
        readyQuantity: 1067,
        netWeight: 5.24,
        grossWeight: 6.48,
        cartonSize: "47x35x13.5",
        cbm: 26,
        colors: [
          { design: "Oil Green", barcode: "8720956911558" },
          { design: "Café Crème", barcode: "8720956911541" },
          { design: "Iron Gate", barcode: "8720956911534" },
          { design: "Stripe Sand", barcode: "8720956911527" },
          { design: "Irish Cream", barcode: "8720956911503" },
          { design: "Silver Grey", barcode: "8720956911510" },
        ],
      },
    ],
  },
  {
    id: "ATM-4402",
    atmNo: "4402",
    customer: "Al-Rehman Textiles",
    date: "22-Jul-26",
    notes: "",
    lines: [
      {
        orderId: "10911",
        article: "Bedsheet Set",
        articleNo: "BS-K1",
        size: "King",
        dimensions: "240x260",
        packPerCtn: 8,
        quantity: 2400,
        readyQuantity: 1600,
        netWeight: 3.1,
        grossWeight: 3.6,
        cartonSize: "45x32x30",
        cbm: 15,
        colors: [
          { design: "Ivory", barcode: "8720956922011" },
          { design: "Charcoal", barcode: "8720956922028" },
          { design: "Blush", barcode: "8720956922035" },
        ],
      },
    ],
  },
  {
    id: "ATM-4415",
    atmNo: "4415",
    customer: "Noor Fabrics Co.",
    date: "27-Jul-26",
    notes: "",
    lines: [
      {
        orderId: "10920",
        article: "Cushion Cover",
        articleNo: "CC-02",
        size: "45x45",
        dimensions: "45x45",
        packPerCtn: 20,
        quantity: 4000,
        readyQuantity: 4000,
        netWeight: 2.4,
        grossWeight: 2.9,
        cartonSize: "40x30x28",
        cbm: 9,
        colors: [
          { design: "Terracotta", barcode: "8720956933110" },
          { design: "Olive", barcode: "8720956933127" },
        ],
      },
    ],
  },
];

function calcLine(line) {
  const pack = Number(line.packPerCtn) || 1;
  const reqdCtns = Math.ceil(line.quantity / pack);
  const readyCtns = Math.ceil(line.readyQuantity / pack);
  const percent = line.quantity ? Math.min(100, Math.round((line.readyQuantity / line.quantity) * 100)) : 0;
  return { ...line, reqdCtns, readyCtns, percent };
}

function calcGroup(group) {
  const lines = group.lines.map(calcLine);
  const totalQuantity = lines.reduce((s, l) => s + l.quantity, 0);
  const totalReady = lines.reduce((s, l) => s + l.readyQuantity, 0);
  const totalReqdCtns = lines.reduce((s, l) => s + l.reqdCtns, 0);
  const totalReadyCtns = lines.reduce((s, l) => s + l.readyCtns, 0);
  const percent = totalQuantity ? Math.min(100, Math.round((totalReady / totalQuantity) * 100)) : 0;
  return { ...group, lines, totalQuantity, totalReady, totalReqdCtns, totalReadyCtns, percent };
}

function statusOf(percent) {
  if (percent >= 100) return "Complete";
  if (percent > 0) return "In progress";
  return "Not started";
}

function statusColors(status) {
  if (status === "Complete") return { bg: COLORS.greenSoft, fg: COLORS.green };
  if (status === "In progress") return { bg: COLORS.goldSoft, fg: COLORS.goldDim };
  return { bg: COLORS.rustSoft, fg: COLORS.rust };
}

function OrdersStatIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M3.5 1.8h9l1 2.7v9c0 .8-.6 1.5-1.5 1.5h-8A1.5 1.5 0 0 1 2.5 13.5v-9l1-2.7z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M5.3 7.2h5.4M5.3 9.8h5.4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}
function SetsIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <rect x="2" y="2" width="8" height="8" rx="1.4" stroke="currentColor" strokeWidth="1.3" />
      <path d="M6.5 6.5h8v8h-8z" stroke="currentColor" strokeWidth="1.3" fill={COLORS.card} />
    </svg>
  );
}
function BoxIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M8 1.7l6 2.9v6.8L8 14.3l-6-2.9V4.6L8 1.7z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M2 4.6L8 7.5l6-2.9M8 7.5v6.8" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
    </svg>
  );
}
function ProgressIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="6.3" stroke="currentColor" strokeWidth="1.3" />
      <path d="M8 8V2.2A5.8 5.8 0 0 1 13.8 8H8z" fill="currentColor" opacity="0.35" />
    </svg>
  );
}
function PlusIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
      <path d="M7 1.5v11M1.5 7h11" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}
function TrashIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 14 14" fill="none">
      <path d="M2.5 4h9M5.5 4V2.5h3V4M3.5 4l.6 8.2c0 .5.5.8 1 .8h3.8c.5 0 .9-.3 1-.8L10.5 4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function InvoiceIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
      <path d="M3.5 1.5h5l2 2v9a1 1 0 0 1-1 1h-6a1 1 0 0 1-1-1V2.5a1 1 0 0 1 1-1z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M8.5 1.5v2h2" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M4.5 7h5M4.5 9h5M4.5 11h3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function ScissorsIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
      <circle cx="4" cy="4" r="2" stroke="currentColor" strokeWidth="1.3" />
      <circle cx="4" cy="12" r="2" stroke="currentColor" strokeWidth="1.3" />
      <path d="M5.5 5.5L14 14M5.5 10.5L14 2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}
function PrintIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <path d="M4.5 6V2.5h7V6" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
      <rect x="2" y="6" width="12" height="5.5" rx="1" stroke="currentColor" strokeWidth="1.3" />
      <path d="M4.5 10v3.5h7V10" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
    </svg>
  );
}
function DownloadIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
      <path d="M8 1.8v8.6M4.3 7.3L8 11l3.7-3.7" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M2.3 12.3v1.4c0 .7.6 1.2 1.2 1.2h9c.7 0 1.2-.5 1.2-1.2v-1.4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function SpinnerIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="spin">
      <circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1.6" strokeOpacity="0.25" />
      <path d="M14 8a6 6 0 0 0-6-6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

function StatusBadge({ status }) {
  const c = statusColors(status);
  return (
    <span className="text-[10.5px] font-semibold px-2 py-1 rounded-full uppercase tracking-wide whitespace-nowrap" style={{ background: c.bg, color: c.fg }}>
      {status}
    </span>
  );
}

function OrderGroupCard({ group, index, onOpen, onInvoice, onPartialSplit }) {
  const status = statusOf(group.percent);
  const c = statusColors(status);
  return (
    <div
      className="order-card fade-in rounded-2xl p-5 cursor-pointer"
      style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, animationDelay: `${index * 50}ms` }}
      onClick={() => onOpen(group)}
    >
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-start gap-3 min-w-0">
          <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0 text-[12px] font-bold" style={{ background: COLORS.boneDim, color: COLORS.goldDim }}>
            {group.atmNo}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-[14px] font-semibold" style={{ color: COLORS.ink }}>{group.customer}</h3>
              <StatusBadge status={status} />
            </div>
            <p className="text-[11.5px] mt-0.5" style={{ color: COLORS.graphiteLight }}>
              ATM {group.atmNo} · {group.lines.length} order line{group.lines.length === 1 ? "" : "s"} · {group.date}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {status === "Complete" ? (
            <button
              type="button"
              className="btn-primary inline-flex items-center gap-1.5 text-[11.5px] font-semibold px-3 py-1.5 rounded-lg shrink-0"
              style={{ background: COLORS.green, color: COLORS.card }}
              onClick={(e) => {
                e.stopPropagation();
                onInvoice(group);
              }}
            >
              <InvoiceIcon /> Create invoice
            </button>
          ) : (
            <button
              type="button"
              className="btn-secondary inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1.5 rounded-lg shrink-0"
              style={{ border: `1px solid ${COLORS.border}`, color: COLORS.graphite, background: COLORS.card }}
              onClick={(e) => {
                e.stopPropagation();
                onPartialSplit(group);
              }}
            >
              <ScissorsIcon /> Partial Split
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 mt-4">
        <div>
          <div className="text-[10px] uppercase tracking-wide font-semibold" style={{ color: COLORS.graphiteLight }}>Total sets</div>
          <div className="text-[14px] font-semibold mt-0.5" style={{ color: COLORS.ink }}>{group.totalQuantity.toLocaleString()}</div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wide font-semibold" style={{ color: COLORS.graphiteLight }}>Cartons</div>
          <div className="text-[14px] font-semibold mt-0.5" style={{ color: COLORS.ink }}>{group.totalReadyCtns.toLocaleString()} / {group.totalReqdCtns.toLocaleString()}</div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wide font-semibold" style={{ color: COLORS.graphiteLight }}>Ready</div>
          <div className="text-[14px] font-semibold mt-0.5" style={{ color: COLORS.ink }}>{group.totalReady.toLocaleString()}</div>
        </div>
      </div>

      <div className="mt-3">
        <div className="h-2 rounded-full overflow-hidden" style={{ background: COLORS.boneDim }}>
          <div className="h-2 rounded-full due-bar" style={{ width: `${group.percent}%`, background: c.fg }} />
        </div>
        <div className="flex items-center justify-between mt-1.5">
          <span className="text-[11px]" style={{ color: COLORS.graphiteLight }}>{group.percent}% against order</span>
          <div className="flex items-center gap-1.5 flex-wrap justify-end">
            {group.lines.map((l) => (
              <span key={l.orderId} className="text-[10.5px] font-medium px-1.5 py-0.5 rounded" style={{ background: COLORS.boneDim, color: COLORS.graphite }}>
                #{l.orderId}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function OrderDetailModal({ group, onClose, onInvoice }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  if (!group) return null;
  const status = statusOf(group.percent);

  return (
    <div className="modal-overlay fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-6" onClick={onClose}>
      <div
        className="modal-pop w-full max-w-4xl max-h-[92vh] overflow-y-auto rounded-2xl"
        style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-start justify-between gap-3 px-6 py-5 sticky top-0 z-10" style={{ background: COLORS.card, borderBottom: `1px solid ${COLORS.border}` }}>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-[16px] font-semibold" style={{ color: COLORS.ink }}>{group.customer}</h2>
              <StatusBadge status={status} />
            </div>
            <p className="text-[11.5px] mt-1" style={{ color: COLORS.graphiteLight }}>ATM No {group.atmNo} · {group.date}</p>
          </div>
          <button type="button" className="btn-secondary p-2 rounded-lg shrink-0" style={{ border: `1px solid ${COLORS.border}`, color: COLORS.graphite }} onClick={onClose} aria-label="Close">
            <CloseIcon />
          </button>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
            <div className="rounded-xl p-4" style={{ background: COLORS.boneDim }}>
              <div className="text-[10.5px] font-semibold uppercase tracking-wide" style={{ color: COLORS.graphite }}>Order lines</div>
              <div className="text-[19px] font-semibold mt-1" style={{ color: COLORS.ink }}>{group.lines.length}</div>
            </div>
            <div className="rounded-xl p-4" style={{ background: COLORS.boneDim }}>
              <div className="text-[10.5px] font-semibold uppercase tracking-wide" style={{ color: COLORS.graphite }}>Total sets</div>
              <div className="text-[19px] font-semibold mt-1" style={{ color: COLORS.ink }}>{group.totalQuantity.toLocaleString()}</div>
            </div>
            <div className="rounded-xl p-4" style={{ background: COLORS.boneDim }}>
              <div className="text-[10.5px] font-semibold uppercase tracking-wide" style={{ color: COLORS.graphite }}>Cartons ready</div>
              <div className="text-[19px] font-semibold mt-1" style={{ color: COLORS.ink }}>{group.totalReadyCtns.toLocaleString()} / {group.totalReqdCtns.toLocaleString()}</div>
            </div>
            <div className="rounded-xl p-4" style={{ background: COLORS.goldSoft }}>
              <div className="text-[10.5px] font-semibold uppercase tracking-wide" style={{ color: COLORS.goldDim }}>% against order</div>
              <div className="text-[19px] font-semibold mt-1" style={{ color: COLORS.ink }}>{group.percent}%</div>
            </div>
          </div>

          {group.notes && (
            <div className="rounded-xl px-4 py-3 mb-4 text-[12px]" style={{ background: COLORS.goldSoft, color: COLORS.goldDim }}>
              {group.notes}
            </div>
          )}

          {/* Client Supplied Fabric & Yield Tracker */}
          <div className="rounded-2xl p-4 mb-6" style={{ background: COLORS.boneDim, border: `1px solid ${COLORS.border}` }}>
            <h4 className="text-[12px] font-semibold uppercase tracking-wider mb-2.5" style={{ color: COLORS.ink }}>Client Supplied Fabric Inventory &amp; Yield Efficiency</h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[12px]">
              <div>
                <span className="text-[10px] uppercase font-semibold block" style={{ color: COLORS.graphite }}>Fabric Received</span>
                <strong style={{ color: COLORS.ink }}>{(group.metersReceived || 5000).toLocaleString()} meters</strong>
              </div>
              <div>
                <span className="text-[10px] uppercase font-semibold block" style={{ color: COLORS.graphite }}>Expected Yield</span>
                <strong style={{ color: COLORS.ink }}>{(group.expectedYield || group.totalQuantity).toLocaleString()} pcs</strong>
              </div>
              <div>
                <span className="text-[10px] uppercase font-semibold block" style={{ color: COLORS.graphite }}>Actual Dispatched</span>
                <strong style={{ color: COLORS.ink }}>{group.totalReady.toLocaleString()} pcs</strong>
              </div>
              <div>
                <span className="text-[10px] uppercase font-semibold block" style={{ color: COLORS.graphite }}>Fabric Wastage %</span>
                <strong className="text-[13px]" style={{ color: COLORS.goldDim }}>
                  {Math.max(0, (((group.expectedYield || group.totalQuantity) - group.totalReady) / (group.expectedYield || group.totalQuantity) * 100)).toFixed(1)}%
                </strong>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            {group.lines.map((line) => (
              <div key={line.orderId} className="rounded-2xl overflow-hidden" style={{ border: `1px solid ${COLORS.border}` }}>
                <div className="flex items-center justify-between flex-wrap gap-2 px-5 py-3" style={{ background: COLORS.boneDim }}>
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="text-[12px] font-bold px-2 py-1 rounded" style={{ background: COLORS.ink, color: COLORS.gold }}>#{line.orderId}</span>
                    <span className="text-[12.5px] font-semibold" style={{ color: COLORS.ink }}>{line.article}</span>
                    <span className="text-[11.5px]" style={{ color: COLORS.graphite }}>{line.size} · {line.dimensions}</span>
                  </div>
                  <StatusBadge status={statusOf(line.percent)} />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 p-5">
                  <div className="lg:col-span-2">
                    <div className="text-[10.5px] font-semibold uppercase tracking-wide mb-2" style={{ color: COLORS.graphiteLight }}>Design / Color</div>
                    <div className="flex flex-col gap-1.5">
                      {line.colors.map((c, i) => (
                        <div key={i} className="flex items-center justify-between text-[12px] px-2.5 py-1.5 rounded-lg" style={{ background: COLORS.bone }}>
                          <span style={{ color: COLORS.ink }}>{c.design} = 1</span>
                          <span className="text-[10.5px] font-mono" style={{ color: COLORS.graphiteLight }}>{c.barcode}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="lg:col-span-3">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      <StatBlock label="Quantity" value={line.quantity.toLocaleString()} />
                      <StatBlock label="Pack / CTN" value={line.packPerCtn} />
                      <StatBlock label="Reqd CTNS" value={line.reqdCtns.toLocaleString()} />
                      <StatBlock label="Ready Qty" value={line.readyQuantity.toLocaleString()} />
                      <StatBlock label="Ready CTNS" value={line.readyCtns.toLocaleString()} />
                      <StatBlock label="% Against order" value={`${line.percent}%`} highlight />
                      <StatBlock label="Carton numbering" value={`1 to ${line.reqdCtns}`} />
                      <StatBlock label="Net / Gross wt" value={`${line.netWeight} / ${line.grossWeight} kg`} />
                      <StatBlock label="Carton size / CBM" value={`${line.cartonSize} · ${line.cbm}`} />
                    </div>
                    <div className="h-1.5 rounded-full overflow-hidden mt-4" style={{ background: COLORS.boneDim }}>
                      <div className="h-1.5 rounded-full due-bar" style={{ width: `${line.percent}%`, background: statusColors(statusOf(line.percent)).fg }} />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {status === "Complete" && (
          <div className="sticky bottom-0 flex items-center justify-between gap-3 px-6 py-4 flex-wrap" style={{ background: COLORS.card, borderTop: `1px solid ${COLORS.border}` }}>
            <span className="text-[11.5px]" style={{ color: COLORS.graphiteLight }}>Every line is packed and ready — this order can be invoiced.</span>
            <button
              type="button"
              className="btn-primary inline-flex items-center gap-1.5 text-[12.5px] font-semibold px-4 py-2 rounded-lg shrink-0"
              style={{ background: COLORS.green, color: COLORS.card }}
              onClick={() => onInvoice(group)}
            >
              <InvoiceIcon /> Create invoice
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function StatBlock({ label, value, highlight }) {
  return (
    <div>
      <div className="text-[9.5px] font-semibold uppercase tracking-wide" style={{ color: COLORS.graphiteLight }}>{label}</div>
      <div className="text-[13px] font-semibold mt-0.5" style={{ color: highlight ? COLORS.goldDim : COLORS.ink }}>{value}</div>
    </div>
  );
}

function buildInvoiceRows(group) {
  const rows = [];
  group.lines.forEach((line) => {
    const perColor = line.colors.length ? Math.round(line.quantity / line.colors.length) : line.quantity;
    line.colors.forEach((c) => {
      rows.push({ description: `${line.article} (${line.size})`, design: c.design, qty: perColor, rate: "" });
    });
  });
  return rows;
}

function InvoiceModal({ group, billNo, onClose }) {
  const [rows, setRows] = useState(() => buildInvoiceRows(group));
  const [name, setName] = useState(group.customer);
  const [orderRef, setOrderRef] = useState(`ATM ${group.atmNo}`);
  const [challanNo, setChallanNo] = useState("");
  const [date, setDate] = useState(new Date().toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" }));
  const [partyName, setPartyName] = useState(group.customer);
  const [jobOrderNo, setJobOrderNo] = useState(group.atmNo);
  const [scNo, setScNo] = useState("");
  const [isExporting, setIsExporting] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  function updateRow(i, field, value) {
    setRows((r) => r.map((row, idx) => (idx === i ? { ...row, [field]: value } : row)));
  }

  const subTotal = rows.reduce((s, r) => s + (Number(r.qty) || 0) * (Number(r.rate) || 0), 0);

  function buildInvoiceElement() {
    return (
      <InvoiceDocument
        billNo={billNo}
        name={name}
        orderRef={orderRef}
        challanNo={challanNo}
        date={date}
        partyName={partyName}
        jobOrderNo={jobOrderNo}
        scNo={scNo}
        rows={rows}
        subTotal={subTotal}
      />
    );
  }

  async function handleDownloadPdf() {
    if (isExporting) return;
    setIsExporting(true);
    try {
      const blob = await pdf(buildInvoiceElement()).toBlob();

      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `Invoice-${billNo}-${group.customer.replace(/\s+/g, "-")}.pdf`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("PDF export failed:", err);
      window.alert("Couldn't generate the PDF. Check the console for details.");
    } finally {
      setIsExporting(false);
    }
  }

  async function handlePrintPdf() {
    if (isPrinting) return;
    setIsPrinting(true);
    try {
      const blob = await pdf(buildInvoiceElement()).toBlob();
      const url = URL.createObjectURL(blob);

      const iframe = document.createElement("iframe");
      iframe.style.position = "fixed";
      iframe.style.right = "0";
      iframe.style.bottom = "0";
      iframe.style.width = "0";
      iframe.style.height = "0";
      iframe.style.border = "none";
      iframe.src = url;

      const cleanup = () => {
        if (iframe.parentNode) iframe.parentNode.removeChild(iframe);
        URL.revokeObjectURL(url);
      };

      iframe.onload = () => {
        try {
          iframe.contentWindow.focus();
          iframe.contentWindow.print();
        } catch (err) {
          console.warn("In-place print failed, opening PDF in a new tab instead:", err);
          window.open(url, "_blank");
        }
        setTimeout(cleanup, 60000);
      };

      document.body.appendChild(iframe);
    } catch (err) {
      console.error("PDF print failed:", err);
      window.alert("Couldn't prepare the PDF for printing. Check the console for details.");
    } finally {
      setIsPrinting(false);
    }
  }

  return (
    <div className="modal-overlay fixed inset-0 z-70 flex items-center justify-center p-3 sm:p-6" onClick={onClose}>
      <div
        className="modal-pop w-full max-w-3xl max-h-[94vh] overflow-y-auto rounded-2xl"
        style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        <div className="no-print flex items-center justify-between gap-3 px-6 py-4 sticky top-0 z-10" style={{ background: COLORS.card, borderBottom: `1px solid ${COLORS.border}` }}>
          <div>
            <h2 className="text-[15px] font-semibold" style={{ color: COLORS.ink }}>Invoice preview</h2>
            <p className="text-[11px] mt-0.5" style={{ color: COLORS.graphiteLight }}>Fill in rates, then download or print — no printer needed to check the layout</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              className="btn-secondary inline-flex items-center gap-1.5 text-[12px] font-semibold px-3 py-2 rounded-lg"
              style={{ border: `1px solid ${COLORS.border}`, color: COLORS.graphite, opacity: isExporting ? 0.7 : 1, cursor: isExporting ? "wait" : "pointer" }}
              onClick={handleDownloadPdf}
              disabled={isExporting}
            >
              {isExporting ? <SpinnerIcon /> : <DownloadIcon />} {isExporting ? "Generating…" : "Download PDF"}
            </button>
            <button
              type="button"
              className="btn-secondary inline-flex items-center gap-1.5 text-[12px] font-semibold px-3 py-2 rounded-lg"
              style={{ border: `1px solid ${COLORS.border}`, color: COLORS.graphite, opacity: isPrinting ? 0.7 : 1, cursor: isPrinting ? "wait" : "pointer" }}
              onClick={handlePrintPdf}
              disabled={isPrinting}
            >
              {isPrinting ? <SpinnerIcon /> : <PrintIcon />} {isPrinting ? "Preparing…" : "Print"}
            </button>
            <button type="button" className="btn-secondary p-2 rounded-lg" style={{ border: `1px solid ${COLORS.border}`, color: COLORS.graphite }} onClick={onClose} aria-label="Close">
              <CloseIcon />
            </button>
          </div>
        </div>

        <div className="invoice-print p-6">
          <div
            className="rounded-lg p-4"
            style={{
              border: "1.5px solid #000",
              width: "100%",
              boxSizing: "border-box",
            }}
          >
            <h1
              className="text-[20px] font-bold tracking-wide"
              style={{ color: "#000", fontFamily: "Georgia, 'Times New Roman', serif", textAlign: "center", margin: 0, lineHeight: 1.4 }}
            >
              NAVEED &amp; SONS
            </h1>
          </div>

          <div className="flex items-center gap-1 mt-4 text-[13px]" style={{ color: "#000" }}>
             <div className="text-[12px] font-bold text-center mb-3 border border-transparent px-3 py-1 rounded-md" style={{ color: "#000" }}>Bill No.</div>
            <div className="mb-3 border border-black px-3 py-1 rounded-md flex item-c">
                <p className="text-[12px] font-bold text-center">{billNo}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mt-3">
            
              <div className="rounded-lg p-4" style={{ border: "1px solid #000" }}>
                <div className="text-[12px] font-bold text-center mb-3" style={{ color: "#000" }}>Billing Details</div>
                <InvoiceField label="Name" value={name} onChange={setName} />
                <InvoiceField label="Order" value={orderRef} onChange={setOrderRef} />
                <InvoiceField label="Challan #" value={challanNo} onChange={setChallanNo} />
              </div>
              <div className="rounded-lg p-4" style={{ border: "1px solid #000" }}>
                <InvoiceField label="Date" value={date} onChange={setDate} />
                <InvoiceField label="Party Name" value={partyName} onChange={setPartyName} />
                <InvoiceField label="Job Order #" value={jobOrderNo} onChange={setJobOrderNo} />
                <InvoiceField label="S/C #" value={scNo} onChange={setScNo} />
              </div>
          </div>

          <div className="mt-4 rounded-lg overflow-hidden" style={{ border: "1px solid #000" }}>
            <table className="w-full text-[12px]" style={{ borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ background: "#fff" }}>
                  <th className="text-center font-semibold px-2 py-2" style={{ border: "1px solid #000", color: "#000" }}>SR#</th>
                  <th className="text-left font-semibold px-3 py-2" style={{ border: "1px solid #000", color: "#000" }}>Description</th>
                  <th className="text-left font-semibold px-3 py-2" style={{ border: "1px solid #000", color: "#000" }}>Design</th>
                  <th className="text-right font-semibold px-3 py-2" style={{ border: "1px solid #000", color: "#000" }}>Qty</th>
                  <th className="text-right font-semibold px-3 py-2" style={{ border: "1px solid #000", color: "#000" }}>Rate</th>
                  <th className="text-right font-semibold px-3 py-2" style={{ border: "1px solid #000", color: "#000" }}>Amount</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row, i) => (
                  <tr key={i}>
                    <td className="text-center px-2 py-1.5" style={{ border: "1px solid #000", color: "#000" }}>{i + 1}</td>
                    <td className="px-1 py-1" style={{ border: "1px solid #000", color: "#000" }}>{row.description}</td>
                    <td className="px-1 py-1" style={{ border: "1px solid #000", color: "#000" }}>{row.design}</td>
                    <td className="px-1 py-1" style={{ border: "1px solid #000", color: "#000" }}>
                      <input className="invoice-cell-input text-right" value={row.qty} onChange={(e) => updateRow(i, "qty", e.target.value)} />
                    </td>
                    <td className="px-1 py-1" style={{ border: "1px solid #000", color: "#000" }}>
                      <input className="invoice-cell-input text-right" placeholder="0" value={row.rate} onChange={(e) => updateRow(i, "rate", e.target.value)} />
                    </td>
                    <td className="text-right px-3 py-1.5 font-medium" style={{ border: "1px solid #000", color: "#000" }}>
                      {((Number(row.qty) || 0) * (Number(row.rate) || 0)).toLocaleString()}
                    </td>
                  </tr>
                ))}
                <tr>
                  <td colSpan={5} className="text-right px-3 py-2 font-semibold" style={{ border: "1px solid #000", color: "#000" }}>Sub Total</td>
                  <td className="text-right px-3 py-2 font-bold" style={{ border: "1px solid #000", color: "#000" }}>{subTotal.toLocaleString()}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mt-10 text-[11px] text-center" style={{ color: "#000" }}>
            <div>
              <div className="pt-6" style={{ borderTop: "1px solid #000" }}>Prepared By</div>
            </div>
            <div>
              <div className="pt-6" style={{ borderTop: "1px solid #000" }}>Approved By</div>
            </div>
            <div>
              <div className="pt-6" style={{ borderTop: "1px solid #000" }}>Checked By</div>
            </div>
            <div>
              <div className="pt-6" style={{ borderTop: "1px solid #000" }}>Contractor</div>
            </div>
          </div>
        </div>

        <div className="no-print px-6 pb-5 text-[11px]" style={{ color: COLORS.graphiteLight }}>
          Once your backend is connected, printing this can automatically move the order off the active list and into an Invoices page.
        </div>
      </div>
    </div>
  );
}

function InvoiceField({ label, value, onChange }) {
  return (
    <div className="flex items-baseline gap-2 mb-2 text-[12px]">
      <span className="font-semibold shrink-0" style={{ color: COLORS.ink, minWidth: 78 }}>{label}:</span>
      <input
        className="invoice-line-input"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

function emptyColorRow() {
  return { design: "", barcode: "" };
}
function emptyLine() {
  return {
    orderId: "",
    article: "",
    articleNo: "",
    size: "",
    dimensions: "",
    packPerCtn: 6,
    quantity: "",
    netWeight: "",
    grossWeight: "",
    cartonSize: "",
    cbm: "",
    colors: [emptyColorRow()],
  };
}
function emptyDraft() {
  return { atmNo: "", customer: "", date: "", lines: [emptyLine()] };
}

function PartialOrderModal({ group, onClose, onConfirmSplit }) {
  const [shippedQty, setShippedQty] = useState(Math.round(group.totalQuantity * 0.6));
  const unitRate = 50;
  const [submitted, setSubmitted] = useState(false);

  const totalQty = group.totalQuantity;
  const remainingQty = Math.max(0, totalQty - Number(shippedQty));
  const invoiceAmount = Number(shippedQty) * unitRate;
  const remainingAmount = remainingQty * unitRate;

  function handleSubmit(e) {
    e.preventDefault();
    if (onConfirmSplit) {
      onConfirmSplit(group, Number(shippedQty), remainingQty);
    }
    setSubmitted(true);
    setTimeout(() => {
      onClose();
    }, 600);
  }

  return (
    <div className="modal-overlay fixed inset-0 z-70 flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="modal-pop w-full max-w-md rounded-2xl p-6 shadow-2xl"
        style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, fontFamily: FONT }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-xl flex items-center justify-center text-[14px] font-bold" style={{ background: COLORS.goldSoft, color: COLORS.goldDim, border: `1px solid ${COLORS.border}` }}>
              <ScissorsIcon />
            </span>
            <div>
              <h3 className="text-[15px] font-semibold" style={{ color: COLORS.ink }}>Partial Order Split &amp; Invoice</h3>
              <p className="text-[11px]" style={{ color: COLORS.graphiteLight }}>ATM {group.atmNo} · {group.customer}</p>
            </div>
          </div>
          <button type="button" className="p-1 rounded-lg" onClick={onClose}><CloseIcon /></button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="rounded-xl p-3.5 mb-4 text-[12px] space-y-1.5" style={{ background: COLORS.boneDim, border: `1px solid ${COLORS.border}` }}>
            <div className="flex justify-between">
              <span style={{ color: COLORS.graphite }}>Original Order Total:</span>
              <strong style={{ color: COLORS.ink }}>{totalQty.toLocaleString()} pcs</strong>
            </div>
            <div className="flex justify-between">
              <span style={{ color: COLORS.graphite }}>Contract Rate:</span>
              <strong style={{ color: COLORS.ink }}>PKR {unitRate} / pc</strong>
            </div>
          </div>

          <div className="mb-4">
            <label className="text-[10.5px] font-semibold uppercase tracking-wider block mb-1" style={{ color: COLORS.graphite }}>Completed Units Ready to Invoice Now *</label>
            <input
              type="number"
              min="1"
              max={totalQty - 1}
              required
              className="form-input text-[14px] font-bold"
              value={shippedQty}
              onChange={(e) => setShippedQty(e.target.value)}
            />
          </div>

          <div className="rounded-xl p-3.5 mb-5 space-y-2 text-[12px]" style={{ background: COLORS.goldSoft, border: `1px solid ${COLORS.border}` }}>
            <div className="flex justify-between">
              <span style={{ color: COLORS.ink }}>Immediate Partial Invoice:</span>
              <strong className="text-[13px]" style={{ color: COLORS.goldDim }}>{shippedQty} pcs ({formatPKR(invoiceAmount)})</strong>
            </div>
            <div className="flex justify-between pt-1 border-t" style={{ borderColor: COLORS.border }}>
              <span style={{ color: COLORS.graphite }}>New Balance Order (Pending):</span>
              <strong style={{ color: COLORS.rust }}>{remainingQty} pcs ({formatPKR(remainingAmount)})</strong>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3">
            <button type="button" className="btn-secondary text-[12px] font-semibold px-4 py-2 rounded-lg" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary text-[12.5px] font-semibold px-4 py-2 rounded-lg" style={{ background: COLORS.gold, color: COLORS.ink }}>
              {submitted ? "Split & Invoiced" : "Process Partial Shipment & Split"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function AddOrderModal({ onClose, onSave }) {
  const [draft, setDraft] = useState(emptyDraft);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  function setField(field, value) {
    setDraft((d) => ({ ...d, [field]: value }));
  }
  function setLineField(idx, field, value) {
    setDraft((d) => ({ ...d, lines: d.lines.map((l, i) => (i === idx ? { ...l, [field]: value } : l)) }));
  }
  function addLine() {
    setDraft((d) => ({ ...d, lines: [...d.lines, emptyLine()] }));
  }
  function removeLine(idx) {
    setDraft((d) => ({ ...d, lines: d.lines.filter((_, i) => i !== idx) }));
  }
  function setColorField(lineIdx, colorIdx, field, value) {
    setDraft((d) => ({
      ...d,
      lines: d.lines.map((l, i) =>
        i !== lineIdx ? l : { ...l, colors: l.colors.map((c, ci) => (ci === colorIdx ? { ...c, [field]: value } : c)) }
      ),
    }));
  }
  function addColor(lineIdx) {
    setDraft((d) => ({ ...d, lines: d.lines.map((l, i) => (i !== lineIdx ? l : { ...l, colors: [...l.colors, emptyColorRow()] })) }));
  }
  function removeColor(lineIdx, colorIdx) {
    setDraft((d) => ({
      ...d,
      lines: d.lines.map((l, i) => (i !== lineIdx ? l : { ...l, colors: l.colors.filter((_, ci) => ci !== colorIdx) })),
    }));
  }

  const isValid =
    draft.atmNo.trim() && draft.customer.trim() && draft.lines.some((l) => l.orderId.trim() && l.article.trim() && Number(l.quantity) > 0);

  function handleSubmit() {
    if (!isValid) return;
    const cleanLines = draft.lines
      .filter((l) => l.orderId.trim() && l.article.trim() && Number(l.quantity) > 0)
      .map((l) => ({
        orderId: l.orderId.trim(),
        article: l.article.trim(),
        articleNo: l.articleNo.trim() || "—",
        size: l.size.trim() || "—",
        dimensions: l.dimensions.trim() || "—",
        packPerCtn: Number(l.packPerCtn) || 1,
        quantity: Number(l.quantity) || 0,
        readyQuantity: 0,
        netWeight: Number(l.netWeight) || 0,
        grossWeight: Number(l.grossWeight) || 0,
        cartonSize: l.cartonSize.trim() || "—",
        cbm: Number(l.cbm) || 0,
        colors: l.colors.filter((c) => c.design.trim()).map((c) => ({ design: c.design.trim(), barcode: c.barcode.trim() || "—" })),
      }));

    onSave({
      id: `ATM-${draft.atmNo.trim()}-${Date.now()}`,
      atmNo: draft.atmNo.trim(),
      customer: draft.customer.trim(),
      date: draft.date.trim() || new Date().toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "2-digit" }),
      notes: "",
      lines: cleanLines,
    });
  }

  return (
    <div className="modal-overlay fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-6" onClick={onClose}>
      <div
        className="modal-pop w-full max-w-3xl max-h-[92vh] overflow-y-auto rounded-2xl"
        style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-start justify-between gap-3 px-6 py-5 sticky top-0 z-10" style={{ background: COLORS.card, borderBottom: `1px solid ${COLORS.border}` }}>
          <div>
            <h2 className="text-[16px] font-semibold" style={{ color: COLORS.ink }}>New order</h2>
            <p className="text-[11.5px] mt-0.5" style={{ color: COLORS.graphiteLight }}>Add an ATM order with one or more order lines</p>
          </div>
          <button type="button" className="btn-secondary p-2 rounded-lg shrink-0" style={{ border: `1px solid ${COLORS.border}`, color: COLORS.graphite }} onClick={onClose} aria-label="Close">
            <CloseIcon />
          </button>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
            <div>
              <label className="form-label">ATM No</label>
              <input className="form-input" value={draft.atmNo} onChange={(e) => setField("atmNo", e.target.value)} placeholder="e.g. 4431" />
            </div>
            <div>
              <label className="form-label">Customer</label>
              <input className="form-input" value={draft.customer} onChange={(e) => setField("customer", e.target.value)} placeholder="e.g. ZEEMAN" />
            </div>
            <div>
              <label className="form-label">Date</label>
              <input className="form-input" value={draft.date} onChange={(e) => setField("date", e.target.value)} placeholder="e.g. 16-Jul-26" />
            </div>
          </div>

          <div className="flex flex-col gap-4">
            {draft.lines.map((line, lineIdx) => (
              <div key={lineIdx} className="line-card rounded-2xl p-4" style={{ border: `1.5px dashed ${COLORS.boneBorder}`, background: COLORS.bone }}>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11.5px] font-semibold uppercase tracking-wide" style={{ color: COLORS.graphite }}>Order line {lineIdx + 1}</span>
                  {draft.lines.length > 1 && (
                    <button type="button" className="icon-btn-remove" onClick={() => removeLine(lineIdx)} aria-label="Remove line">
                      <TrashIcon />
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
                  <div>
                    <label className="form-label">Order #</label>
                    <input className="form-input" value={line.orderId} onChange={(e) => setLineField(lineIdx, "orderId", e.target.value)} placeholder="10897" />
                  </div>
                  <div>
                    <label className="form-label">Article</label>
                    <input className="form-input" value={line.article} onChange={(e) => setLineField(lineIdx, "article", e.target.value)} placeholder="Duvet Cover Set" />
                  </div>
                  <div>
                    <label className="form-label">Article #</label>
                    <input className="form-input" value={line.articleNo} onChange={(e) => setLineField(lineIdx, "articleNo", e.target.value)} placeholder="optional" />
                  </div>
                  <div>
                    <label className="form-label">Size</label>
                    <input className="form-input" value={line.size} onChange={(e) => setLineField(lineIdx, "size", e.target.value)} placeholder="Single" />
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
                  <div>
                    <label className="form-label">Dimensions</label>
                    <input className="form-input" value={line.dimensions} onChange={(e) => setLineField(lineIdx, "dimensions", e.target.value)} placeholder="140x200 · 60x70" />
                  </div>
                  <div>
                    <label className="form-label">Pack / CTN</label>
                    <input type="number" className="form-input" value={line.packPerCtn} onChange={(e) => setLineField(lineIdx, "packPerCtn", e.target.value)} placeholder="6" />
                  </div>
                  <div>
                    <label className="form-label">Quantity</label>
                    <input type="number" className="form-input" value={line.quantity} onChange={(e) => setLineField(lineIdx, "quantity", e.target.value)} placeholder="5502" />
                  </div>
                  <div>
                    <label className="form-label">Reqd CTNS</label>
                    <input className="form-input" value={line.quantity && line.packPerCtn ? Math.ceil(Number(line.quantity) / Number(line.packPerCtn)) : ""} disabled placeholder="auto" style={{ color: COLORS.graphiteLight, background: COLORS.boneDim }} />
                  </div>
                </div>

                <details className="mb-3">
                  <summary className="text-[11px] font-semibold cursor-pointer select-none" style={{ color: COLORS.goldDim }}>
                    Shipping details (optional)
                  </summary>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-2.5">
                    <div>
                      <label className="form-label">Net weight (kg)</label>
                      <input type="number" className="form-input" value={line.netWeight} onChange={(e) => setLineField(lineIdx, "netWeight", e.target.value)} />
                    </div>
                    <div>
                      <label className="form-label">Gross weight (kg)</label>
                      <input type="number" className="form-input" value={line.grossWeight} onChange={(e) => setLineField(lineIdx, "grossWeight", e.target.value)} />
                    </div>
                    <div>
                      <label className="form-label">Carton size</label>
                      <input className="form-input" value={line.cartonSize} onChange={(e) => setLineField(lineIdx, "cartonSize", e.target.value)} placeholder="47x35x14" />
                    </div>
                    <div>
                      <label className="form-label">CBM</label>
                      <input type="number" className="form-input" value={line.cbm} onChange={(e) => setLineField(lineIdx, "cbm", e.target.value)} />
                    </div>
                  </div>
                </details>

                <div>
                  <label className="form-label mb-2">Design / Color</label>
                  <div className="flex flex-col gap-2">
                    {line.colors.map((c, colorIdx) => (
                      <div key={colorIdx} className="flex items-center gap-2">
                        <input className="form-input" style={{ flex: 2 }} value={c.design} onChange={(e) => setColorField(lineIdx, colorIdx, "design", e.target.value)} placeholder="Oil Green" />
                        <input className="form-input" style={{ flex: 2 }} value={c.barcode} onChange={(e) => setColorField(lineIdx, colorIdx, "barcode", e.target.value)} placeholder="barcode (optional)" />
                        {line.colors.length > 1 && (
                          <button type="button" className="icon-btn-remove shrink-0" onClick={() => removeColor(lineIdx, colorIdx)} aria-label="Remove color">
                            <TrashIcon />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                  <button type="button" className="btn-dashed mt-2.5" onClick={() => addColor(lineIdx)}>
                    <PlusIcon /> Add color
                  </button>
                </div>
              </div>
            ))}
          </div>

          <button type="button" className="btn-dashed mt-4 w-full justify-center py-3" onClick={addLine}>
            <PlusIcon /> Add order line
          </button>
        </div>

        <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4" style={{ background: COLORS.card, borderTop: `1px solid ${COLORS.border}` }}>
          <button type="button" className="btn-secondary text-[12.5px] font-medium px-4 py-2 rounded-lg" style={{ border: `1px solid ${COLORS.border}`, color: COLORS.graphite }} onClick={onClose}>
            Cancel
          </button>
          <button
            type="button"
            className="btn-primary text-[12.5px] font-semibold px-4 py-2 rounded-lg"
            style={{ background: isValid ? COLORS.gold : COLORS.boneBorder, color: isValid ? COLORS.ink : COLORS.graphiteLight, cursor: isValid ? "pointer" : "not-allowed" }}
            onClick={handleSubmit}
            disabled={!isValid}
          >
            Add order
          </button>
        </div>
      </div>
    </div>
  );
}

export default function OrdersPage() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All statuses");
  const [orderGroupsRaw, setOrderGroupsRaw] = useState(ORDER_GROUPS_SEED);
  const [openGroupId, setOpenGroupId] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [invoiceGroupId, setInvoiceGroupId] = useState(null);
  const [partialSplitGroup, setPartialSplitGroup] = useState(null);
  const [billNumbers, setBillNumbers] = useState({});
  const [nextBillNo, setNextBillNo] = useState(2309);

  const orderGroups = useMemo(() => orderGroupsRaw.map(calcGroup), [orderGroupsRaw]);
  const openGroup = useMemo(() => orderGroups.find((g) => g.id === openGroupId) || null, [orderGroups, openGroupId]);
  const invoiceGroup = useMemo(() => orderGroups.find((g) => g.id === invoiceGroupId) || null, [orderGroups, invoiceGroupId]);

  function handleOpenInvoice(group) {
    if (!billNumbers[group.id]) {
      setBillNumbers((prev) => ({ ...prev, [group.id]: nextBillNo }));
      setNextBillNo((n) => n + 1);
    }
    setInvoiceGroupId(group.id);
    setOpenGroupId(null);
  }

  function handleConfirmSplit(group, shippedQty, remainingQty) {
    setOrderGroupsRaw((prev) => {
      const updated = prev.map((g) => {
        if (g.id === group.id) {
          return {
            ...g,
            lines: g.lines.map((l) => ({ ...l, quantity: shippedQty })),
          };
        }
        return g;
      });

      const newSplitOrder = {
        id: `grp-${Date.now()}`,
        atmNo: `${group.atmNo}-B`,
        customer: `${group.customer} (Balance)`,
        date: new Date().toISOString().split("T")[0],
        lines: group.lines.map((l) => ({
          ...l,
          quantity: remainingQty,
          colors: l.colors.map((c) => ({ ...c, ready: 0 })),
        })),
      };

      return [newSplitOrder, ...updated];
    });

    handleOpenInvoice(group);
    setPartialSplitGroup(null);
  }

  const filtered = useMemo(() => {
    return orderGroups
      .filter((g) => (statusFilter === "All statuses" ? true : statusOf(g.percent) === statusFilter))
      .filter((g) => {
        const q = search.toLowerCase();
        return g.customer.toLowerCase().includes(q) || g.atmNo.includes(q) || g.lines.some((l) => l.orderId.includes(q));
      });
  }, [orderGroups, search, statusFilter]);

  const totalOrders = orderGroups.length;
  const totalSets = orderGroups.reduce((s, g) => s + g.totalQuantity, 0);
  const totalCartons = orderGroups.reduce((s, g) => s + g.totalReqdCtns, 0);
  const readyCartons = orderGroups.reduce((s, g) => s + g.totalReadyCtns, 0);

  function handleSaveOrder(newGroup) {
    setOrderGroupsRaw((prev) => [newGroup, ...prev]);
    setShowAddModal(false);
  }

  return (
    <div className="min-h-screen w-full flex" style={{ background: COLORS.bone, fontFamily: FONT }}>
      <Sidebar mobileOpen={mobileNavOpen} onClose={() => setMobileNavOpen(false)} />

      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-3 px-5 md:px-8 py-4 sticky top-0 z-30 backdrop-blur" style={{ background: `${COLORS.bone}F2`, borderBottom: `1px solid ${COLORS.border}` }}>
          <div className="flex items-center gap-3 min-w-0">
            <button type="button" className="md:hidden p-2 rounded-lg btn-secondary shrink-0" style={{ background: COLORS.card, border: `1px solid ${COLORS.border}` }} onClick={() => setMobileNavOpen(true)} aria-label="Open navigation">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2 4h12M2 8h12M2 12h12" stroke={COLORS.ink} strokeWidth="1.4" strokeLinecap="round" />
              </svg>
            </button>
            <div className="min-w-0">
              <h1 className="text-xl font-semibold truncate" style={{ color: COLORS.ink }}>Orders</h1>
              <p className="text-[12px]" style={{ color: COLORS.graphiteLight }}>{totalOrders} ATM order{totalOrders === 1 ? "" : "s"} on the floor</p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 shrink-0">
            <button type="button" className="btn-primary inline-flex items-center gap-1.5 text-[12.5px] font-semibold px-3.5 py-2 rounded-lg" style={{ background: COLORS.gold, color: COLORS.ink }} onClick={() => setShowAddModal(true)}>
              <PlusIcon /> <span className="hidden xs:inline">New order</span>
            </button>
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-[13px] font-semibold shrink-0" style={{ background: COLORS.ink, color: COLORS.gold, border: `2px solid ${COLORS.goldSoft}` }}>
              A
            </div>
          </div>
        </div>

        <div className="p-5 md:p-8 max-w-7xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <MiniStat index={0} icon={<OrdersStatIcon />} label="ATM orders" value={totalOrders} sub="active on the floor" />
            <MiniStat index={1} icon={<SetsIcon />} label="Total sets" value={totalSets.toLocaleString()} sub="across all orders" />
            <MiniStat index={2} icon={<BoxIcon />} label="Cartons ready" value={`${readyCartons.toLocaleString()} / ${totalCartons.toLocaleString()}`} sub="packed vs required" />
            <MiniStat index={3} icon={<ProgressIcon />} label="In progress" value={orderGroups.filter((g) => statusOf(g.percent) === "In progress").length} sub={`${orderGroups.filter((g) => statusOf(g.percent) === "Not started").length} not started`} />
          </div>

          <div className="flex flex-wrap items-center gap-3 mb-4">
            <div className="search-wrap">
              <SearchIcon />
              <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search customer, ATM no, order #" style={{ width: 260 }} />
            </div>
            <div className="select-wrap">
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                {["All statuses", "Not started", "In progress", "Complete"].map((opt) => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="select-caret">
                <path d="M2.5 4.5L6 8l3.5-3.5" stroke={COLORS.graphite} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <span className="text-[11.5px] ml-auto" style={{ color: COLORS.graphiteLight }}>{filtered.length} shown</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filtered.map((group, i) => (
              <OrderGroupCard
                key={group.id}
                group={group}
                index={i}
                onOpen={(g) => setOpenGroupId(g.id)}
                onInvoice={handleOpenInvoice}
                onPartialSplit={(g) => setPartialSplitGroup(g)}
              />
            ))}
            {filtered.length === 0 && (
              <div className="lg:col-span-2 rounded-2xl p-8 text-center text-[12.5px]" style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, color: COLORS.graphiteLight }}>
                No orders match your search.
              </div>
            )}
          </div>
        </div>
      </div>

      {openGroup && <OrderDetailModal group={openGroup} onClose={() => setOpenGroupId(null)} onInvoice={handleOpenInvoice} />}
      {partialSplitGroup && <PartialOrderModal group={partialSplitGroup} onClose={() => setPartialSplitGroup(null)} onConfirmSplit={handleConfirmSplit} />}
      {showAddModal && <AddOrderModal onClose={() => setShowAddModal(false)} onSave={handleSaveOrder} />}
      {invoiceGroup && <InvoiceModal group={invoiceGroup} billNo={billNumbers[invoiceGroup.id]} onClose={() => setInvoiceGroupId(null)} />}

      <style>{`
        * { box-sizing: border-box; }

        @keyframes fadeInUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes modalPop { from { opacity: 0; transform: scale(0.96) translateY(6px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        @keyframes overlayIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes growBar { from { width: 0; } }

        .fade-in { animation: fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) both; }
        .due-bar { animation: growBar 0.7s cubic-bezier(0.16, 1, 0.3, 1) both; }

        .modal-overlay { background: rgba(28,25,23,0.5); backdrop-filter: blur(2px); animation: overlayIn 0.18s ease both; }
        .modal-pop { animation: modalPop 0.22s cubic-bezier(0.16, 1, 0.3, 1) both; }

        .stat-card, .order-card, .btn-primary, .btn-secondary, .btn-link, .btn-dashed, .icon-btn-remove {
          transition: transform .18s ease, box-shadow .18s ease, background-color .18s ease, border-color .18s ease, color .18s ease;
        }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 14px 28px -18px rgba(28,25,23,0.28); border-color: ${COLORS.gold} !important; }
        .order-card:hover { transform: translateY(-2px); box-shadow: 0 12px 26px -16px rgba(28,25,23,0.24); border-color: ${COLORS.gold} !important; }

        .btn-primary:hover { filter: brightness(1.06); transform: translateY(-1px); box-shadow: 0 8px 18px -8px rgba(184,135,61,0.5); }
        .btn-primary:active { transform: translateY(0); }
        .btn-primary:disabled:hover { filter: none; transform: none; box-shadow: none; }
        .btn-secondary:hover { border-color: ${COLORS.gold} !important; color: ${COLORS.goldDim} !important; background: ${COLORS.goldSoft}55 !important; }

        .btn-dashed {
          border: 1.5px dashed ${COLORS.boneBorder}; border-radius: 10px; padding: 9px 14px; font-size: 12px; font-weight: 600;
          color: ${COLORS.graphite}; background: transparent; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; font-family: ${FONT};
        }
        .btn-dashed:hover { border-color: ${COLORS.gold}; color: ${COLORS.goldDim}; background: ${COLORS.goldSoft}33; }

        .icon-btn-remove {
          width: 24px; height: 24px; border-radius: 999px; display: flex; align-items: center; justify-content: center;
          background: ${COLORS.rustSoft}; color: ${COLORS.rust}; border: none; cursor: pointer;
        }
        .icon-btn-remove:hover { background: ${COLORS.rust}; color: ${COLORS.card}; }

        .form-label { font-size: 10.5px; font-weight: 600; text-transform: uppercase; letter-spacing: .03em; color: ${COLORS.graphite}; margin-bottom: 4px; display: block; }
        .form-input {
          font-family: ${FONT}; font-size: 12.5px; color: ${COLORS.ink}; background: ${COLORS.card};
          border: 1px solid ${COLORS.border}; border-radius: 8px; padding: 7px 10px; outline: none; width: 100%;
          transition: border-color .2s ease, box-shadow .2s ease;
        }
        .form-input:hover, .form-input:focus { border-color: ${COLORS.gold}; box-shadow: 0 0 0 3px ${COLORS.goldSoft}66; }
        .form-input:disabled { cursor: not-allowed; }

        button:focus-visible, select:focus-visible, input:focus-visible { outline: 2px solid ${COLORS.gold}; outline-offset: 2px; }

        .select-wrap { position: relative; display: inline-flex; align-items: center; }
        .select-wrap select {
          appearance: none; font-family: ${FONT}; font-size: 12.5px; font-weight: 500;
          color: ${COLORS.ink}; background: ${COLORS.card}; border: 1px solid ${COLORS.border};
          border-radius: 8px; padding: 8px 28px 8px 12px; cursor: pointer; outline: none;
          transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }
        .select-wrap select:hover, .select-wrap select:focus { border-color: ${COLORS.gold}; box-shadow: 0 0 0 3px ${COLORS.goldSoft}66; }
        .select-caret { position: absolute; right: 10px; pointer-events: none; }

        .search-wrap { position: relative; display: inline-flex; align-items: center; }
        .search-wrap svg { position: absolute; left: 10px; color: ${COLORS.graphiteLight}; pointer-events: none; }
        .search-wrap input {
          font-family: ${FONT}; font-size: 12.5px; color: ${COLORS.ink}; background: ${COLORS.card};
          border: 1px solid ${COLORS.border}; border-radius: 8px; padding: 8px 12px 8px 30px;
          outline: none; transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }
        .search-wrap input::placeholder { color: ${COLORS.graphiteLight}; }
        .search-wrap input:hover, .search-wrap input:focus { border-color: ${COLORS.gold}; box-shadow: 0 0 0 3px ${COLORS.goldSoft}66; }

        .nav-item { transition: background .18s ease, transform .18s ease, color .18s ease; }
        .nav-item:hover:not(:disabled) { background: ${COLORS.inkSoft} !important; transform: translateX(2px); }

        details summary::-webkit-details-marker { display: none; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .spin { animation: spin 0.8s linear infinite; }

        details summary { list-style: none; }

        .invoice-line-input {
          flex: 1; font-family: ${FONT}; font-size: 12px; color: #000; background: transparent;
          border: none; border-bottom: 1px solid #000; outline: none; padding: 2px 2px;
        }
        .invoice-line-input:focus { border-color: #000; }
        .invoice-cell-input {
          width: 100%; font-family: ${FONT}; font-size: 12px; color: ${COLORS.ink}; background: transparent;
          border: none; outline: none; padding: 2px 4px;
        }
        .invoice-cell-input:focus { background: ${COLORS.goldSoft}55; border-radius: 4px; }

        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: ${COLORS.boneBorder}; border-radius: 8px; }
        ::-webkit-scrollbar-thumb:hover { background: ${COLORS.graphiteLight}; }

        @media print {
          body * { visibility: hidden; }
          .invoice-print, .invoice-print * { visibility: visible; }
          .invoice-print { position: absolute; top: 0; left: 0; width: 100%; padding: 0 !important; }
          .no-print { display: none !important; }
        }

        @media (prefers-reduced-motion: reduce) {
          .fade-in, .due-bar, .stat-card, .order-card, .modal-pop, .modal-overlay, .btn-primary, .btn-secondary { animation: none !important; transition: none !important; }
        }
      `}</style>
    </div>
  );
}